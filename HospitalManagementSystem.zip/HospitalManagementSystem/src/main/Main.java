package main;

import ui.LoginFrame;
import utils.UIUtils;

import javax.swing.*;

/** Application entry point. */
public class Main {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) { }

        // a few global defaults so dialogs match the rest of the application
        UIManager.put("OptionPane.messageFont", UIUtils.regular(13));
        UIManager.put("OptionPane.buttonFont",  UIUtils.bold(13));
        UIManager.put("Label.font",             UIUtils.regular(13));
        UIManager.put("ToolTip.font",           UIUtils.regular(12));
        UIManager.put("TabbedPane.font",        UIUtils.bold(13));

        SwingUtilities.invokeLater(new Runnable() {
            @Override public void run() {
                new LoginFrame().setVisible(true);
            }
        });
    }
}
