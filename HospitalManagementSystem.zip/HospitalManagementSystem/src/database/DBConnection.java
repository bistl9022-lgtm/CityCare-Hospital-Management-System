package database;

import java.sql.*;

/**
 * Single place where the JDBC connection is created and shared.
 * No UI class ever touches DriverManager directly.
 */
public class DBConnection {

    private static final String HOST = "localhost";
    private static final String PORT = "3306";
    private static final String DB   = "hospital_db";
    private static final String USER = "root";
    private static final String PASS = "root";          // <-- change to your MySQL password

    private static final String URL =
            "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB +
            "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    private static Connection connection;

    private DBConnection() { }

    /** Returns a live connection, creating it on first use. */
    public static Connection get() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(
                    "MySQL JDBC driver not found.\nAdd mysql-connector-j-x.x.x.jar to the project classpath.");
            }
            connection = DriverManager.getConnection(URL, USER, PASS);
        }
        return connection;
    }

    /** Friendly message used by the login screen when the database is unreachable. */
    public static String testConnection() {
        try {
            get();
            return null;                       // null means "everything is fine"
        } catch (SQLException e) {
            return "Cannot connect to MySQL.\n\n" + e.getMessage() +
                   "\n\nCheck that:\n  1. MySQL server is running\n" +
                   "  2. Database 'hospital_db' exists (run database/hospital.sql)\n" +
                   "  3. Username / password in DBConnection.java are correct";
        }
    }

    /** Runs a query that returns a single number (COUNT / SUM). */
    public static double scalar(String sql, Object... args) {
        try (PreparedStatement ps = get().prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getDouble(1);
            }
        } catch (SQLException e) {
            System.err.println("scalar() failed: " + e.getMessage());
        }
        return 0;
    }

    public static void close() {
        try {
            if (connection != null && !connection.isClosed()) connection.close();
        } catch (SQLException ignored) { }
    }
}
