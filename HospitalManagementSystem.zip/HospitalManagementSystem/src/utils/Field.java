package utils;

/**
 * Describes one input on a form. The CrudPanel builds the widget, reads the
 * value and validates it purely from this description, so no module has to
 * repeat layout or validation code.
 */
public class Field {

    public enum Type { TEXT, INT, DECIMAL, EMAIL, PHONE, DATE, TIME, COMBO }

    public final String   key;        // column-ish name, used as map key
    public final String   label;      // shown to the user and as table header
    public final Type     type;
    public final boolean  required;
    public final String[] options;    // only for COMBO

    public Field(String key, String label, Type type, boolean required, String... options) {
        this.key = key;
        this.label = label;
        this.type = type;
        this.required = required;
        this.options = options;
    }

    // ---- short factory helpers, keeps panel code readable -------------------
    public static Field text(String key, String label)            { return new Field(key, label, Type.TEXT, true); }
    public static Field opt(String key, String label)             { return new Field(key, label, Type.TEXT, false); }
    public static Field num(String key, String label)             { return new Field(key, label, Type.INT, true); }
    public static Field money(String key, String label)           { return new Field(key, label, Type.DECIMAL, true); }
    public static Field email(String key, String label)           { return new Field(key, label, Type.EMAIL, false); }
    public static Field phone(String key, String label)           { return new Field(key, label, Type.PHONE, true); }
    public static Field date(String key, String label)            { return new Field(key, label, Type.DATE, true); }
    public static Field dateOpt(String key, String label)         { return new Field(key, label, Type.DATE, false); }
    public static Field time(String key, String label)            { return new Field(key, label, Type.TIME, true); }
    public static Field combo(String key, String label, String... o) { return new Field(key, label, Type.COMBO, true, o); }
}
