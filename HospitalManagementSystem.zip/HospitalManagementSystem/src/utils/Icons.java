package utils;

import javax.swing.Icon;
import java.awt.*;
import java.awt.geom.*;

/**
 * Small vector icon set drawn with Java2D. Using shapes instead of image files
 * keeps the project to source code only and guarantees crisp icons everywhere.
 */
public class Icons implements Icon {

    private final String name;
    private final int size;
    private final Color color;

    public Icons(String name, int size, Color color) {
        this.name = name; this.size = size; this.color = color;
    }

    public static Icon of(String name, int size, Color c) { return new Icons(name, size, c); }

    @Override public int getIconWidth()  { return size; }
    @Override public int getIconHeight() { return size; }

    @Override
    public void paintIcon(Component c, Graphics g, int x, int y) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.translate(x, y);
        double s = size / 24.0;                 // all shapes designed on a 24x24 grid
        g2.scale(s, s);
        g2.setColor(color);
        g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        draw(g2);
        g2.dispose();
    }

    private void draw(Graphics2D g) {
        if (name.equals("dashboard")) {
            g.fill(new RoundRectangle2D.Double(3, 3, 8, 8, 3, 3));
            g.fill(new RoundRectangle2D.Double(13, 3, 8, 5, 3, 3));
            g.fill(new RoundRectangle2D.Double(3, 13, 8, 8, 3, 3));
            g.fill(new RoundRectangle2D.Double(13, 10, 8, 11, 3, 3));
        } else if (name.equals("patients") || name.equals("user")) {
            g.fill(new Ellipse2D.Double(8, 3, 8, 8));
            g.fill(new Arc2D.Double(3, 13, 18, 18, 0, 180, Arc2D.PIE));
        } else if (name.equals("doctors")) {
            g.fill(new Ellipse2D.Double(8.5, 2, 7, 7));
            g.fill(new Arc2D.Double(4, 11, 16, 16, 0, 180, Arc2D.PIE));
            g.setColor(Color.WHITE);
            g.fill(new Rectangle2D.Double(11.2, 13, 1.8, 6));
            g.fill(new Rectangle2D.Double(9.1, 15.1, 6, 1.8));
        } else if (name.equals("appointments") || name.equals("calendar")) {
            g.draw(new RoundRectangle2D.Double(3, 5, 18, 16, 3, 3));
            g.draw(new Line2D.Double(3, 10, 21, 10));
            g.draw(new Line2D.Double(8, 2.5, 8, 6));
            g.draw(new Line2D.Double(16, 2.5, 16, 6));
            g.fill(new Rectangle2D.Double(7, 13, 3, 3));
            g.fill(new Rectangle2D.Double(14, 13, 3, 3));
        } else if (name.equals("records") || name.equals("file")) {
            g.draw(new RoundRectangle2D.Double(5, 2.5, 14, 19, 3, 3));
            g.draw(new Line2D.Double(9, 8, 15, 8));
            g.draw(new Line2D.Double(9, 12, 15, 12));
            g.draw(new Line2D.Double(9, 16, 13, 16));
        } else if (name.equals("billing") || name.equals("money")) {
            g.draw(new RoundRectangle2D.Double(2.5, 5.5, 19, 13, 3, 3));
            g.draw(new Ellipse2D.Double(9, 9, 6, 6));
            g.fill(new Ellipse2D.Double(5, 11, 2, 2));
            g.fill(new Ellipse2D.Double(17, 11, 2, 2));
        } else if (name.equals("pharmacy") || name.equals("pill")) {
            g.draw(new RoundRectangle2D.Double(3, 9, 18, 7, 3.5, 3.5));
            g.draw(new Line2D.Double(12, 9, 12, 16));
            g.draw(new Line2D.Double(7.5, 3, 7.5, 7));
            g.draw(new Line2D.Double(5.5, 5, 9.5, 5));
        } else if (name.equals("laboratory") || name.equals("flask")) {
            g.draw(new Line2D.Double(9, 2.5, 15, 2.5));
            g.draw(new Line2D.Double(10.5, 2.5, 10.5, 10));
            g.draw(new Line2D.Double(13.5, 2.5, 13.5, 10));
            Path2D p = new Path2D.Double();
            p.moveTo(10.5, 10); p.lineTo(5, 19); p.lineTo(19, 19); p.lineTo(13.5, 10); p.closePath();
            g.draw(p);
            g.fill(new Rectangle2D.Double(7.3, 15.5, 9.4, 3.5));
        } else if (name.equals("staff")) {
            g.fill(new Ellipse2D.Double(3, 5, 6, 6));
            g.fill(new Arc2D.Double(0, 12, 12, 12, 0, 180, Arc2D.PIE));
            g.fill(new Ellipse2D.Double(14, 5, 6, 6));
            g.fill(new Arc2D.Double(11, 12, 12, 12, 0, 180, Arc2D.PIE));
        } else if (name.equals("reports") || name.equals("chart")) {
            g.draw(new Line2D.Double(3, 20.5, 21, 20.5));
            g.fill(new RoundRectangle2D.Double(5, 12, 4, 7, 1.5, 1.5));
            g.fill(new RoundRectangle2D.Double(10.5, 7, 4, 12, 1.5, 1.5));
            g.fill(new RoundRectangle2D.Double(16, 3, 4, 16, 1.5, 1.5));
        } else if (name.equals("settings") || name.equals("gear")) {
            g.draw(new Ellipse2D.Double(8.5, 8.5, 7, 7));
            for (int i = 0; i < 8; i++) {
                double a = Math.toRadians(i * 45);
                g.draw(new Line2D.Double(12 + 8.5 * Math.cos(a), 12 + 8.5 * Math.sin(a),
                                         12 + 10.5 * Math.cos(a), 12 + 10.5 * Math.sin(a)));
            }
        } else if (name.equals("logout")) {
            g.draw(new RoundRectangle2D.Double(3.5, 3.5, 9, 17, 3, 3));
            g.draw(new Line2D.Double(14, 12, 21, 12));
            g.draw(new Line2D.Double(17.5, 8.5, 21, 12));
            g.draw(new Line2D.Double(17.5, 15.5, 21, 12));
        } else if (name.equals("search")) {
            g.draw(new Ellipse2D.Double(4, 4, 12, 12));
            g.draw(new Line2D.Double(15, 15, 20.5, 20.5));
        } else if (name.equals("bell")) {
            Path2D p = new Path2D.Double();
            p.moveTo(5, 17); p.lineTo(5, 11); p.curveTo(5, 6, 9, 4, 12, 4);
            p.curveTo(15, 4, 19, 6, 19, 11); p.lineTo(19, 17); p.closePath();
            g.draw(p);
            g.draw(new Arc2D.Double(9.5, 17, 5, 5, 200, 140, Arc2D.OPEN));
        } else if (name.equals("bed")) {
            g.draw(new Line2D.Double(2.5, 7, 2.5, 19));
            g.draw(new Line2D.Double(2.5, 18, 21.5, 18));
            g.draw(new Line2D.Double(21.5, 12, 21.5, 19));
            g.draw(new RoundRectangle2D.Double(2.5, 10, 19, 8, 3, 3));
            g.fill(new Ellipse2D.Double(5.5, 8.5, 5, 5));
        } else if (name.equals("emergency") || name.equals("cross")) {
            g.fill(new RoundRectangle2D.Double(9.5, 3, 5, 18, 2, 2));
            g.fill(new RoundRectangle2D.Double(3, 9.5, 18, 5, 2, 2));
        } else if (name.equals("refresh")) {
            g.draw(new Arc2D.Double(4, 4, 16, 16, 60, 250, Arc2D.OPEN));
            g.fill(new Polygon(new int[]{17, 23, 20}, new int[]{4, 6, 11}, 3));
        } else if (name.equals("eye")) {
            g.draw(new Arc2D.Double(1.5, 4.5, 21, 15, 0, 180, Arc2D.OPEN));
            g.draw(new Arc2D.Double(1.5, 4.5, 21, 15, 180, 180, Arc2D.OPEN));
            g.fill(new Ellipse2D.Double(9.5, 9.5, 5, 5));
        } else {
            g.draw(new Ellipse2D.Double(4, 4, 16, 16));
        }
    }
}
