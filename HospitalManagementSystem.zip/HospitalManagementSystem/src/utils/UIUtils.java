package utils;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * One place for colours, fonts, borders and every reusable widget.
 * Every other class builds its screen from these helpers, which is what keeps
 * the rest of the project short.
 */
public class UIUtils {

    // ===================== THEME =====================
    public static final Color PRIMARY      = new Color(14, 116, 144);   // teal 700
    public static final Color PRIMARY_DARK = new Color(11, 78, 98);
    public static final Color ACCENT       = new Color(13, 148, 136);
    public static final Color BG           = new Color(241, 245, 249);
    public static final Color CARD         = Color.WHITE;
    public static final Color TEXT         = new Color(15, 23, 42);
    public static final Color MUTED        = new Color(100, 116, 139);
    public static final Color BORDER       = new Color(226, 232, 240);
    public static final Color DANGER       = new Color(220, 38, 38);
    public static final Color SUCCESS      = new Color(22, 163, 74);
    public static final Color WARNING      = new Color(217, 119, 6);
    public static final Color INFO         = new Color(37, 99, 235);
    public static final Color SIDEBAR      = new Color(12, 41, 53);
    public static final Color SIDEBAR_HOVER= new Color(20, 66, 84);

    public static final String HOSPITAL_NAME = "City Care Multispeciality Hospital";
    public static final int    TOTAL_BEDS    = 120;

    private static final String FAMILY = pickFont();

    private static String pickFont() {
        String[] wanted = {"Segoe UI", "Inter", "Roboto", "Helvetica Neue", "SansSerif"};
        java.util.List<String> have = java.util.Arrays.asList(
                GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames());
        for (String w : wanted) if (have.contains(w)) return w;
        return "SansSerif";
    }

    public static Font font(int size, int style) { return new Font(FAMILY, style, size); }
    public static Font regular(int size) { return font(size, Font.PLAIN); }
    public static Font bold(int size)    { return font(size, Font.BOLD); }

    // ===================== BASIC WIDGETS =====================

    public static JLabel label(String text, int size, int style, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font(size, style));
        l.setForeground(color);
        return l;
    }

    public static JLabel title(String text)    { return label(text, 22, Font.BOLD, TEXT); }
    public static JLabel section(String text)  { return label(text, 15, Font.BOLD, TEXT); }
    public static JLabel caption(String text)  { return label(text, 12, Font.PLAIN, MUTED); }

    /** Rounded white card with soft border. */
    public static JPanel roundPanel(final Color bg, final int radius) {
        JPanel p = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
                g2.setColor(BORDER);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        p.setOpaque(false);
        p.setLayout(new BorderLayout());
        return p;
    }

    /** Card with an optional bold heading already placed at the top. */
    public static JPanel card(String heading) {
        JPanel p = roundPanel(CARD, 16);
        p.setBorder(new EmptyBorder(16, 18, 16, 18));
        if (heading != null) {
            JPanel head = new JPanel(new BorderLayout());
            head.setOpaque(false);
            head.setBorder(new EmptyBorder(0, 0, 12, 0));
            head.add(section(heading), BorderLayout.WEST);
            p.add(head, BorderLayout.NORTH);
        }
        return p;
    }

    /** Flat rounded button with hover + pressed states. */
    public static JButton button(String text, final Color bg, final Color fg, String iconName) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color c = bg;
                if (getModel().isPressed())      c = shade(bg, -0.18);
                else if (getModel().isRollover()) c = shade(bg, 0.12);
                g2.setColor(c);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                if (bg.equals(Color.WHITE)) {
                    g2.setColor(BORDER);
                    g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };
        b.setFont(bold(13));
        b.setForeground(fg);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setOpaque(false);
        b.setBorder(new EmptyBorder(9, 16, 9, 16));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        if (iconName != null) {
            b.setIcon(Icons.of(iconName, 15, fg));
            b.setIconTextGap(8);
        }
        return b;
    }

    public static JButton primary(String t, String icon) { return button(t, PRIMARY, Color.WHITE, icon); }
    public static JButton accent(String t, String icon)  { return button(t, ACCENT, Color.WHITE, icon); }
    public static JButton danger(String t, String icon)  { return button(t, DANGER, Color.WHITE, icon); }
    public static JButton ghost(String t, String icon)   { return button(t, Color.WHITE, TEXT, icon); }

    public static Color shade(Color c, double f) {
        int r = clamp((int) (c.getRed()   + 255 * f));
        int g = clamp((int) (c.getGreen() + 255 * f));
        int b = clamp((int) (c.getBlue()  + 255 * f));
        return new Color(r, g, b);
    }
    private static int clamp(int v) { return Math.max(0, Math.min(255, v)); }

    public static JTextField textField() {
        JTextField t = new JTextField();
        styleInput(t);
        return t;
    }

    public static JPasswordField passwordField() {
        JPasswordField p = new JPasswordField();
        styleInput(p);
        return p;
    }

    public static <T> JComboBox<T> comboBox(T[] items) {
        JComboBox<T> c = new JComboBox<T>(items);
        c.setFont(regular(13));
        c.setBackground(Color.WHITE);
        c.setForeground(TEXT);
        c.setBorder(new CompoundBorder(new LineBorder(BORDER, 1, true), new EmptyBorder(4, 8, 4, 8)));
        c.setPreferredSize(new Dimension(160, 34));
        return c;
    }

    public static void styleInput(javax.swing.text.JTextComponent t) {
        t.setFont(regular(13));
        t.setForeground(TEXT);
        t.setBorder(new CompoundBorder(new LineBorder(BORDER, 1, true), new EmptyBorder(7, 10, 7, 10)));
        t.setPreferredSize(new Dimension(160, 34));
        t.setBackground(Color.WHITE);
    }

    /** Wraps a styled table in a scroll pane. Call only once per table. */
    public static JScrollPane styledTable(JTable t) {
        styleTable(t);
        JScrollPane sp = new JScrollPane(t);
        sp.setBorder(new LineBorder(BORDER, 1, true));
        sp.getViewport().setBackground(Color.WHITE);
        return sp;
    }

    /** Applies fonts, row height and renderers. Safe to call again after the model changes. */
    public static void styleTable(JTable t) {
        t.setFont(regular(13));
        t.setRowHeight(32);
        t.setGridColor(new Color(241, 245, 249));
        t.setShowVerticalLines(false);
        t.setSelectionBackground(new Color(224, 242, 245));
        t.setSelectionForeground(TEXT);
        t.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        t.setFillsViewportHeight(true);
        t.getTableHeader().setFont(bold(13));
        t.getTableHeader().setBackground(new Color(248, 250, 252));
        t.getTableHeader().setForeground(MUTED);
        t.getTableHeader().setPreferredSize(new Dimension(10, 36));
        t.getTableHeader().setReorderingAllowed(false);

        DefaultTableCellRenderer r = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable tb, Object v, boolean sel,
                                                                     boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(tb, v, sel, foc, row, col);
                setBorder(new EmptyBorder(0, 10, 0, 10));
                if (!sel) c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(250, 251, 252));
                return c;
            }
        };
        for (int i = 0; i < t.getColumnCount(); i++) {
            t.getColumnModel().getColumn(i).setCellRenderer(r);
            t.getColumnModel().getColumn(i).setPreferredWidth(140);
        }
    }

    /** Small coloured pill used for status / priority columns. */
    public static Color statusColor(String value) {
        if (value == null) return MUTED;
        String v = value.toLowerCase();
        if (v.contains("emergency") || v.contains("cancel") || v.contains("expired")) return DANGER;
        if (v.contains("high") || v.contains("pending") || v.contains("low stock")) return WARNING;
        if (v.contains("complete") || v.contains("paid") || v.contains("available")) return SUCCESS;
        if (v.contains("process") || v.contains("schedul")) return INFO;
        return MUTED;
    }

    // ===================== DIALOGS =====================
    public static void info(Component c, String msg) {
        JOptionPane.showMessageDialog(c, msg, "Information", JOptionPane.INFORMATION_MESSAGE);
    }
    public static void error(Component c, String msg) {
        JOptionPane.showMessageDialog(c, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
    public static void warn(Component c, String msg) {
        JOptionPane.showMessageDialog(c, msg, "Please check", JOptionPane.WARNING_MESSAGE);
    }
    public static boolean confirm(Component c, String msg) {
        return JOptionPane.showConfirmDialog(c, msg, "Please confirm",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION;
    }

    /** Scrollable read-only text dialog (used by View / Print / Report preview). */
    public static void textDialog(Component parent, String title, String body) {
        JTextArea a = new JTextArea(body);
        a.setEditable(false);
        a.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        a.setBorder(new EmptyBorder(10, 12, 10, 12));
        JScrollPane sp = new JScrollPane(a);
        sp.setPreferredSize(new Dimension(520, 420));
        JOptionPane.showMessageDialog(parent, sp, title, JOptionPane.PLAIN_MESSAGE);
    }

    // ===================== VALIDATION =====================

    public static boolean isEmail(String s) { return s.matches("^[\\w.+-]+@[\\w-]+\\.[\\w.]{2,}$"); }
    public static boolean isPhone(String s) { return s.matches("^[0-9]{10}$"); }
    public static boolean isDate(String s)  { return s.matches("^\\d{4}-\\d{2}-\\d{2}$") && parseDate(s) != null; }
    public static boolean isTime(String s)  { return s.matches("^([01]?\\d|2[0-3]):[0-5]\\d$"); }

    public static Date parseDate(String s) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
            f.setLenient(false);
            return f.parse(s);
        } catch (Exception e) { return null; }
    }

    public static int toInt(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }
    public static double toDouble(String s) {
        try { return Double.parseDouble(s.trim()); } catch (Exception e) { return 0; }
    }
    public static String money(double d) { return String.format("%.2f", d); }

    public static String today() { return new SimpleDateFormat("yyyy-MM-dd").format(new Date()); }
    public static String nowStamp() {
        return new SimpleDateFormat("EEE, dd MMM yyyy  |  hh:mm:ss a").format(new Date());
    }

    /**
     * Validates every value against its Field description.
     * @return null when everything is valid, otherwise the message to show.
     */
    public static String validate(Field[] fields, Map<String, String> values) {
        for (Field f : fields) {
            String v = values.get(f.key);
            if (v == null) v = "";
            v = v.trim();

            if (f.required && v.isEmpty()) return "\"" + f.label + "\" cannot be empty.";
            if (v.isEmpty()) continue;                       // optional + blank is fine

            switch (f.type) {
                case INT:
                    if (!v.matches("^\\d+$")) return "\"" + f.label + "\" must be a whole number.";
                    if (f.key.equals("age") && (toInt(v) < 0 || toInt(v) > 120))
                        return "Age must be between 0 and 120.";
                    break;
                case DECIMAL:
                    if (!v.matches("^\\d+(\\.\\d{1,2})?$"))
                        return "\"" + f.label + "\" must be a positive amount (negative values are not allowed).";
                    break;
                case EMAIL:
                    if (!isEmail(v)) return "\"" + f.label + "\" is not a valid email address.";
                    break;
                case PHONE:
                    if (!isPhone(v)) return "\"" + f.label + "\" must be exactly 10 digits.";
                    break;
                case DATE:
                    if (!isDate(v)) return "\"" + f.label + "\" must be a real date in yyyy-MM-dd format.";
                    break;
                case TIME:
                    if (!isTime(v)) return "\"" + f.label + "\" must be a time in HH:mm format (24 hour).";
                    break;
                default:
                    break;
            }
        }
        return null;
    }

    /** Adds a simple hover highlight to any component. */
    public static void hover(final JComponent c, final Color normal, final Color hovered) {
        c.setBackground(normal);
        c.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { c.setBackground(hovered); }
            @Override public void mouseExited (MouseEvent e) { c.setBackground(normal); }
        });
    }
}
