package service;

import model.Bill;
import utils.UIUtils;

/** All money arithmetic for the Billing screen lives here, never in the UI. */
public class BillingService {

    /** Consultation + room + medicine + laboratory + other charges. */
    public static double subtotal(Bill b) {
        return b.getConsultationFee() + b.getRoomCharges() + b.getMedicineCharges()
             + b.getLabCharges() + b.getOtherCharges();
    }

    /** Discount is stored as a percentage of the subtotal. */
    public static double discountAmount(Bill b) {
        double pct = Math.max(0, Math.min(100, b.getDiscount()));
        return subtotal(b) * pct / 100.0;
    }

    /** Subtotal -> discount -> final payable total. */
    public static double total(Bill b) {
        double t = subtotal(b) - discountAmount(b);
        return Math.round(Math.max(0, t) * 100.0) / 100.0;
    }

    /** Printable receipt used by the Print button. */
    public static String receipt(Bill b) {
        StringBuilder s = new StringBuilder();
        String line = "--------------------------------------------\n";
        s.append(center(UIUtils.HOSPITAL_NAME)).append("\n");
        s.append(center("Patient Bill / Receipt")).append("\n").append(line);
        s.append(pair("Bill ID", b.getBillId()));
        s.append(pair("Patient ID", b.getPatientId()));
        s.append(pair("Patient Name", b.getPatientName()));
        s.append(pair("Date", b.getDate()));
        s.append(line);
        s.append(amount("Consultation Fee", b.getConsultationFee()));
        s.append(amount("Room Charges", b.getRoomCharges()));
        s.append(amount("Medicine Charges", b.getMedicineCharges()));
        s.append(amount("Laboratory Charges", b.getLabCharges()));
        s.append(amount("Other Charges", b.getOtherCharges()));
        s.append(line);
        s.append(amount("Subtotal", subtotal(b)));
        s.append(amount("Discount (" + UIUtils.money(b.getDiscount()) + "%)", -discountAmount(b)));
        s.append(line);
        s.append(amount("TOTAL PAYABLE", total(b)));
        s.append(line);
        s.append(pair("Payment Status", b.getPaymentStatus()));
        s.append(pair("Payment Method", b.getPaymentMethod()));
        s.append(line);
        s.append(center("Thank you and get well soon")).append("\n");
        return s.toString();
    }

    private static String pair(String k, String v) {
        return String.format("%-22s: %s%n", k, v == null ? "" : v);
    }
    private static String amount(String k, double v) {
        return String.format("%-22s: %14s%n", k, "Rs. " + UIUtils.money(v));
    }
    private static String center(String s) {
        int pad = Math.max(0, (44 - s.length()) / 2);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < pad; i++) sb.append(' ');
        return sb.append(s).toString();
    }
}
