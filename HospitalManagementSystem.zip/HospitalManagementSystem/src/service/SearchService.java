package service;

import dao.ReportDAO;
import model.TableData;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

/** Backs the global search box in the header (case-insensitive, all modules). */
public class SearchService {

    public static Map<String, TableData> searchEverywhere(String keyword) throws SQLException {
        String k = "%" + (keyword == null ? "" : keyword.trim().toLowerCase()) + "%";
        Map<String, TableData> out = new LinkedHashMap<String, TableData>();

        out.put("Patients", ReportDAO.run(
            "SELECT patient_id AS 'Patient ID', full_name AS 'Name', phone AS 'Phone', " +
            "disease AS 'Problem', priority AS 'Priority' FROM patients " +
            "WHERE LOWER(patient_id) LIKE ? OR LOWER(full_name) LIKE ? OR LOWER(phone) LIKE ? " +
            "OR LOWER(IFNULL(disease,'')) LIKE ?", k, k, k, k));

        out.put("Doctors", ReportDAO.run(
            "SELECT doctor_id AS 'Doctor ID', name AS 'Name', specialization AS 'Specialization', " +
            "availability AS 'Availability' FROM doctors " +
            "WHERE LOWER(doctor_id) LIKE ? OR LOWER(name) LIKE ? OR LOWER(IFNULL(specialization,'')) LIKE ?",
            k, k, k));

        out.put("Appointments", ReportDAO.run(
            "SELECT appointment_id AS 'Appointment ID', patient_id AS 'Patient', doctor_id AS 'Doctor', " +
            "appt_date AS 'Date', appt_time AS 'Time', status AS 'Status' FROM appointments " +
            "WHERE LOWER(appointment_id) LIKE ? OR LOWER(patient_id) LIKE ? OR LOWER(doctor_id) LIKE ? " +
            "OR LOWER(IFNULL(department,'')) LIKE ?", k, k, k, k));

        out.put("Bills", ReportDAO.run(
            "SELECT bill_id AS 'Bill ID', patient_id AS 'Patient ID', patient_name AS 'Patient', " +
            "total_amount AS 'Total', payment_status AS 'Status' FROM bills " +
            "WHERE LOWER(bill_id) LIKE ? OR LOWER(patient_id) LIKE ? OR LOWER(IFNULL(patient_name,'')) LIKE ?",
            k, k, k));

        return out;
    }
}
