package ui;

import dao.BaseDAO;
import dao.StaffDAO;
import model.Staff;
import utils.Field;
import utils.UIUtils;

import java.util.Map;

/** Non-doctor hospital staff: nurses, reception, pharmacy, laboratory and admin. */
public class StaffPanel extends CrudPanel<Staff> {

    private final StaffDAO dao = new StaffDAO();

    public StaffPanel() {
        super("Staff Management",
              "Maintain hospital staff records, shifts and salaries.",
              new Field[]{
                Field.text("staff_id", "Staff ID"),
                Field.text("name", "Name"),
                Field.combo("role", "Role", "Nurse", "Receptionist", "Pharmacist",
                        "Technician", "Accountant", "Administrator"),
                Field.combo("department", "Department", "Front Desk", "ICU", "General Ward",
                        "Pharmacy", "Laboratory", "Accounts", "Administration", "Emergency"),
                Field.phone("phone", "Phone"),
                Field.email("email", "Email"),
                Field.money("salary", "Salary"),
                Field.date("joining_date", "Joining Date"),
                Field.combo("shift", "Shift", "Morning", "Evening", "Night")
              });
        clearForm();
        refresh("");
    }

    @Override protected BaseDAO<Staff> dao() { return dao; }
    @Override protected String idPrefix()    { return "S"; }

    @Override
    protected Staff fromForm(Map<String, String> v) {
        return new Staff(v.get("staff_id"), v.get("name"), v.get("role"), v.get("department"),
                v.get("phone"), v.get("email"), UIUtils.toDouble(v.get("salary")),
                v.get("joining_date"), v.get("shift"));
    }

    @Override protected void afterClear() { setValue("joining_date", UIUtils.today()); }
}
