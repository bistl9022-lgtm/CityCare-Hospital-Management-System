package ui;

import dao.BaseDAO;
import dao.MedicalRecordDAO;
import model.MedicalRecord;
import utils.Field;
import utils.UIUtils;

import java.util.Map;

/** Diagnosis, treatment and prescription history for each patient. */
public class MedicalRecordPanel extends CrudPanel<MedicalRecord> {

    private final MedicalRecordDAO dao = new MedicalRecordDAO();

    public MedicalRecordPanel() {
        super("Medical Records",
              "Store diagnosis, symptoms, treatment and prescriptions against a patient.",
              new Field[]{
                Field.text("record_id", "Record ID"),
                Field.text("patient_id", "Patient ID"),
                Field.text("doctor_id", "Doctor ID"),
                Field.text("diagnosis", "Diagnosis"),
                Field.text("symptoms", "Symptoms"),
                Field.text("treatment", "Treatment"),
                Field.opt("prescription", "Prescription"),
                Field.opt("test_results", "Test Results"),
                Field.opt("notes", "Notes"),
                Field.date("record_date", "Date")
              });
        clearForm();
        refresh("");
    }

    @Override protected BaseDAO<MedicalRecord> dao() { return dao; }
    @Override protected String idPrefix()            { return "MR"; }

    @Override
    protected MedicalRecord fromForm(Map<String, String> v) {
        return new MedicalRecord(v.get("record_id"), v.get("patient_id"), v.get("doctor_id"),
                v.get("diagnosis"), v.get("symptoms"), v.get("treatment"), v.get("prescription"),
                v.get("test_results"), v.get("notes"), v.get("record_date"));
    }

    @Override protected void afterClear() { setValue("record_date", UIUtils.today()); }
}
