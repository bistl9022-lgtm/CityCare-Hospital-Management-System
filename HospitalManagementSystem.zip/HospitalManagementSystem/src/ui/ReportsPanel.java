package ui;

import dao.ReportDAO;
import model.TableData;
import utils.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/** Read-only reporting with date filters, printing and CSV export. */
public class ReportsPanel extends JPanel implements Refreshable {

    private static final String[] REPORTS = {
        "Patient Report", "Doctor Report", "Appointment Report",
        "Billing Report", "Pharmacy Report", "Laboratory Report"
    };
    private static final String[] PERIODS = {
        "All Records", "Today", "This Week", "This Month", "Custom Date"
    };

    private final JComboBox<String> reportBox = UIUtils.comboBox(REPORTS);
    private final JComboBox<String> periodBox = UIUtils.comboBox(PERIODS);
    private final JTextField fromField = UIUtils.textField();
    private final JTextField toField   = UIUtils.textField();
    private final JLabel     summary   = UIUtils.caption("Choose a report and press Generate.");

    private final DefaultTableModel model = new DefaultTableModel() {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);

    public ReportsPanel() {
        setLayout(new BorderLayout(0, 14));
        setBorder(new EmptyBorder(18, 18, 18, 18));
        setBackground(UIUtils.BG);

        fromField.setText(UIUtils.today());
        toField.setText(UIUtils.today());

        add(buildControls(), BorderLayout.NORTH);

        JPanel card = UIUtils.card(null);
        JPanel head = new JPanel(new BorderLayout());
        head.setOpaque(false);
        head.setBorder(new EmptyBorder(0, 0, 10, 0));
        head.add(UIUtils.section("Report Output"), BorderLayout.WEST);
        head.add(summary, BorderLayout.EAST);
        card.add(head, BorderLayout.NORTH);
        card.add(UIUtils.styledTable(table), BorderLayout.CENTER);
        add(card, BorderLayout.CENTER);
    }

    private JPanel buildControls() {
        JPanel card = UIUtils.card(null);

        JPanel head = new JPanel();
        head.setOpaque(false);
        head.setLayout(new BoxLayout(head, BoxLayout.Y_AXIS));
        JLabel t = UIUtils.label("Reports", 17, Font.BOLD, UIUtils.TEXT);
        t.setAlignmentX(LEFT_ALIGNMENT);
        JLabel s = UIUtils.caption("Generate, print or export hospital data for any period.");
        s.setAlignmentX(LEFT_ALIGNMENT);
        head.add(t);
        head.add(Box.createVerticalStrut(2));
        head.add(s);
        head.setBorder(new EmptyBorder(0, 0, 14, 0));

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        row.setOpaque(false);
        row.add(labelled("Report", reportBox));
        row.add(labelled("Period", periodBox));
        row.add(labelled("From (yyyy-MM-dd)", fromField));
        row.add(labelled("To (yyyy-MM-dd)", toField));

        JButton gen = UIUtils.primary("Generate", "chart");
        JButton print = UIUtils.ghost("Print", "file");
        JButton export = UIUtils.ghost("Export CSV", null);
        gen.addActionListener(e -> generate());
        print.addActionListener(e -> print());
        export.addActionListener(e -> export());

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttons.setOpaque(false);
        buttons.setBorder(new EmptyBorder(12, 0, 0, 0));
        buttons.add(gen); buttons.add(print); buttons.add(export);

        periodBox.addActionListener(e -> {
            boolean custom = "Custom Date".equals(periodBox.getSelectedItem());
            fromField.setEnabled(custom);
            toField.setEnabled(custom);
        });
        fromField.setEnabled(false);
        toField.setEnabled(false);

        card.add(head, BorderLayout.NORTH);
        card.add(row, BorderLayout.CENTER);
        card.add(buttons, BorderLayout.SOUTH);
        return card;
    }

    private JPanel labelled(String text, JComponent comp) {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setOpaque(false);
        p.add(UIUtils.label(text, 12, Font.BOLD, UIUtils.MUTED), BorderLayout.NORTH);
        comp.setPreferredSize(new Dimension(190, 34));
        p.add(comp, BorderLayout.CENTER);
        return p;
    }

    // ------------------------------------------------------------- generating

    private void generate() {
        String report = String.valueOf(reportBox.getSelectedItem());
        String[] q = queryFor(report);           // [0] = sql without WHERE, [1] = date column or ""
        String sql = q[0];
        String dateCol = q[1];

        String[] range = range();
        java.util.List<Object> args = new java.util.ArrayList<Object>();
        if (!dateCol.isEmpty() && range != null) {
            sql += " WHERE " + dateCol + " BETWEEN ? AND ?";
            args.add(range[0]);
            args.add(range[1]);
        }

        try {
            TableData d = ReportDAO.run(sql, args.toArray());
            model.setDataVector(d.matrix(), d.columns);
            UIUtils.styleTable(table);
            summary.setText(d.size() + " row(s)"
                    + (range == null || dateCol.isEmpty() ? "" : "  |  " + range[0] + " to " + range[1]));
        } catch (Exception ex) {
            UIUtils.error(this, "Could not generate the report.\n\n" + ex.getMessage());
        }
    }

    private String[] queryFor(String report) {
        if (report.startsWith("Patient"))
            return new String[]{ "SELECT patient_id AS 'Patient ID', full_name AS 'Name', age AS 'Age', " +
                    "gender AS 'Gender', phone AS 'Phone', disease AS 'Problem', " +
                    "admission_date AS 'Admitted', room_no AS 'Room', doctor AS 'Doctor', " +
                    "priority AS 'Priority' FROM patients", "admission_date" };
        if (report.startsWith("Doctor"))
            return new String[]{ "SELECT doctor_id AS 'Doctor ID', name AS 'Name', " +
                    "specialization AS 'Specialization', experience AS 'Experience', " +
                    "availability AS 'Availability', room_no AS 'Room' FROM doctors", "" };
        if (report.startsWith("Appointment"))
            return new String[]{ "SELECT appointment_id AS 'Appointment ID', patient_id AS 'Patient', " +
                    "doctor_id AS 'Doctor', appt_date AS 'Date', appt_time AS 'Time', " +
                    "department AS 'Department', status AS 'Status' FROM appointments", "appt_date" };
        if (report.startsWith("Billing"))
            return new String[]{ "SELECT bill_id AS 'Bill ID', patient_id AS 'Patient ID', " +
                    "patient_name AS 'Patient', total_amount AS 'Total', " +
                    "payment_status AS 'Status', payment_method AS 'Method', " +
                    "bill_date AS 'Date' FROM bills", "bill_date" };
        if (report.startsWith("Pharmacy"))
            return new String[]{ "SELECT medicine_id AS 'Medicine ID', name AS 'Medicine', " +
                    "category AS 'Category', quantity AS 'Quantity', price AS 'Price', " +
                    "expiry_date AS 'Expiry', supplier AS 'Supplier' FROM medicines", "" };
        return new String[]{ "SELECT test_id AS 'Test ID', patient_id AS 'Patient ID', " +
                "patient_name AS 'Patient', test_name AS 'Test', status AS 'Status', " +
                "cost AS 'Cost', test_date AS 'Date' FROM laboratory_tests", "test_date" };
    }

    /** Converts the selected period into a from/to pair, or null for "All Records". */
    private String[] range() {
        String period = String.valueOf(periodBox.getSelectedItem());
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        String today = f.format(c.getTime());

        if ("All Records".equals(period)) return null;
        if ("Today".equals(period))       return new String[]{ today, today };
        if ("This Week".equals(period)) {
            c.add(Calendar.DAY_OF_MONTH, -6);
            return new String[]{ f.format(c.getTime()), today };
        }
        if ("This Month".equals(period)) {
            c.set(Calendar.DAY_OF_MONTH, 1);
            return new String[]{ f.format(c.getTime()), today };
        }
        String from = fromField.getText().trim(), to = toField.getText().trim();
        if (!UIUtils.isDate(from) || !UIUtils.isDate(to)) {
            UIUtils.warn(this, "Enter both custom dates in yyyy-MM-dd format.");
            return new String[]{ today, today };
        }
        return new String[]{ from, to };
    }

    // ------------------------------------------------------- print and export

    private void print() {
        if (model.getRowCount() == 0) { UIUtils.warn(this, "Generate a report before printing."); return; }
        try {
            table.print(JTable.PrintMode.FIT_WIDTH,
                    new java.text.MessageFormat(UIUtils.HOSPITAL_NAME + " - " + reportBox.getSelectedItem()),
                    new java.text.MessageFormat("Page {0}"));
        } catch (java.awt.print.PrinterException ex) {
            UIUtils.error(this, "Printing failed.\n\n" + ex.getMessage());
        }
    }

    private void export() {
        if (model.getRowCount() == 0) { UIUtils.warn(this, "Generate a report before exporting."); return; }
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new java.io.File(
                String.valueOf(reportBox.getSelectedItem()).replace(' ', '_') + ".csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

        PrintWriter out = null;
        try {
            out = new PrintWriter(new FileWriter(chooser.getSelectedFile()));
            StringBuilder head = new StringBuilder();
            for (int c = 0; c < model.getColumnCount(); c++)
                head.append(c == 0 ? "" : ",").append(escape(model.getColumnName(c)));
            out.println(head);
            for (int r = 0; r < model.getRowCount(); r++) {
                StringBuilder line = new StringBuilder();
                for (int c = 0; c < model.getColumnCount(); c++) {
                    Object v = model.getValueAt(r, c);
                    line.append(c == 0 ? "" : ",").append(escape(v == null ? "" : v.toString()));
                }
                out.println(line);
            }
            UIUtils.info(this, "Report exported to:\n" + chooser.getSelectedFile().getAbsolutePath());
        } catch (Exception ex) {
            UIUtils.error(this, "Export failed.\n\n" + ex.getMessage());
        } finally {
            if (out != null) out.close();
        }
    }

    private String escape(String s) {
        return s.contains(",") || s.contains("\"") ? "\"" + s.replace("\"", "\"\"") + "\"" : s;
    }

    @Override public void reload() { }
}
