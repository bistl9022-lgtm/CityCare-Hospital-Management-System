package ui;

import dao.BaseDAO;
import dao.MedicineDAO;
import model.Medicine;
import utils.Field;
import utils.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.util.Map;

/** Pharmacy stock with low-stock and expiry checks. */
public class PharmacyPanel extends CrudPanel<Medicine> {

    private final MedicineDAO dao = new MedicineDAO();

    public PharmacyPanel() {
        super("Pharmacy",
              "Medicine stock, pricing and expiry. Items at or below "
                      + MedicineDAO.LOW_STOCK_LEVEL + " units are marked low.",
              new Field[]{
                Field.text("medicine_id", "Medicine ID"),
                Field.text("name", "Medicine Name"),
                Field.combo("category", "Category", "Tablet", "Capsule", "Syrup", "Injection",
                        "Ointment", "Powder", "Drops"),
                Field.num("quantity", "Quantity"),
                Field.money("price", "Price"),
                Field.date("expiry_date", "Expiry Date"),
                Field.text("supplier", "Supplier")
              });
        highlightStock();
        clearForm();
        refresh("");
    }

    @Override protected BaseDAO<Medicine> dao() { return dao; }
    @Override protected String idPrefix()       { return "M"; }
    @Override protected String addLabel()       { return "Add Medicine"; }

    @Override
    protected Medicine fromForm(Map<String, String> v) {
        return new Medicine(v.get("medicine_id"), v.get("name"), v.get("category"),
                UIUtils.toInt(v.get("quantity")), UIUtils.toDouble(v.get("price")),
                v.get("expiry_date"), v.get("supplier"));
    }

    @Override
    protected JButton[] extraButtons() {
        JButton low = UIUtils.button("Low Stock", UIUtils.WARNING, Color.WHITE, null);
        low.addActionListener(e -> {
            try {
                setRows(dao.lowStock());
                statusLabel.setText("showing medicines at or below " + MedicineDAO.LOW_STOCK_LEVEL + " units");
            } catch (Exception ex) { UIUtils.error(this, "Could not load low stock.\n\n" + ex.getMessage()); }
        });

        JButton exp = UIUtils.danger("Expired Medicines", null);
        exp.addActionListener(e -> {
            try {
                setRows(dao.expired(UIUtils.today()));
                statusLabel.setText("showing medicines expired before " + UIUtils.today());
            } catch (Exception ex) { UIUtils.error(this, "Could not load expired list.\n\n" + ex.getMessage()); }
        });
        return new JButton[]{ low, exp };
    }

    /** Quantity is painted in warning colour when the stock is running out. */
    private void highlightStock() {
        DefaultTableCellRenderer r = new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                                     boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                setBorder(new EmptyBorder(0, 10, 0, 10));
                int qty = UIUtils.toInt(String.valueOf(v));
                boolean low = qty <= MedicineDAO.LOW_STOCK_LEVEL;
                setFont(low ? UIUtils.bold(13) : UIUtils.regular(13));
                if (!sel) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(250, 251, 252));
                    c.setForeground(low ? UIUtils.DANGER : UIUtils.TEXT);
                }
                return c;
            }
        };
        table.getColumnModel().getColumn(3).setCellRenderer(r);
    }
}
