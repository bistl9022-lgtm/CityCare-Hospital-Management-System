package ui;

import dao.BaseDAO;
import dao.LaboratoryDAO;
import model.LaboratoryTest;
import utils.Field;
import utils.UIUtils;

import javax.swing.JButton;
import java.util.Map;

/** Laboratory tests, their progress and results. */
public class LaboratoryPanel extends CrudPanel<LaboratoryTest> {

    private final LaboratoryDAO dao = new LaboratoryDAO();

    public LaboratoryPanel() {
        super("Laboratory",
              "Register tests, track their status and record the results.",
              new Field[]{
                Field.text("test_id", "Test ID"),
                Field.text("patient_id", "Patient ID"),
                Field.text("patient_name", "Patient Name"),
                Field.combo("test_name", "Test Name", "Complete Blood Count", "Blood Sugar",
                        "Lipid Profile", "Liver Function Test", "Kidney Function Test",
                        "Urine Routine", "X-Ray", "ECG", "MRI Scan", "CT Scan", "Ultrasound"),
                Field.text("doctor", "Doctor"),
                Field.date("test_date", "Test Date"),
                Field.opt("result", "Result"),
                Field.combo("status", "Status", "Pending", "Processing", "Completed"),
                Field.money("cost", "Cost")
              });
        clearForm();
        refresh("");
    }

    @Override protected BaseDAO<LaboratoryTest> dao() { return dao; }
    @Override protected String idPrefix()             { return "L"; }
    @Override protected String addLabel()             { return "Add Test"; }

    @Override
    protected LaboratoryTest fromForm(Map<String, String> v) {
        return new LaboratoryTest(v.get("test_id"), v.get("patient_id"), v.get("patient_name"),
                v.get("test_name"), v.get("doctor"), v.get("test_date"), v.get("result"),
                v.get("status"), UIUtils.toDouble(v.get("cost")));
    }

    @Override protected void afterClear() { setValue("test_date", UIUtils.today()); }

    @Override
    protected JButton[] extraButtons() {
        JButton view = UIUtils.accent("View Result", "eye");
        view.addActionListener(e -> viewResult());

        JButton pending = UIUtils.ghost("Pending Tests", null);
        pending.addActionListener(e -> {
            try { setRows(dao.byStatus("Pending")); }
            catch (Exception ex) { UIUtils.error(this, "Could not filter tests.\n\n" + ex.getMessage()); }
        });
        return new JButton[]{ view, pending };
    }

    private void viewResult() {
        Map<String, String> v = getValues();
        if (v.get("test_id").isEmpty()) {
            UIUtils.warn(this, "Select a test from the table first.");
            return;
        }
        String result = v.get("result");
        if (result.isEmpty()) result = "(result not entered yet - status is " + v.get("status") + ")";
        UIUtils.textDialog(this, "Laboratory result",
                "Test ID      : " + v.get("test_id") + "\n" +
                "Patient      : " + v.get("patient_id") + " - " + v.get("patient_name") + "\n" +
                "Test         : " + v.get("test_name") + "\n" +
                "Referred by  : " + v.get("doctor") + "\n" +
                "Date         : " + v.get("test_date") + "\n" +
                "Status       : " + v.get("status") + "\n" +
                "Cost         : Rs. " + UIUtils.money(UIUtils.toDouble(v.get("cost"))) + "\n\n" +
                "Result\n------\n" + result);
    }
}
