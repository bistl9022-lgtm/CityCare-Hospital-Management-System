package ui;

import dao.BaseDAO;
import dao.BillingDAO;
import model.Bill;
import service.BillingService;
import utils.Field;
import utils.UIUtils;

import javax.swing.JButton;
import java.util.Map;

/** Billing: charges are summed, the discount applied and the total calculated. */
public class BillingPanel extends CrudPanel<Bill> {

    private final BillingDAO dao = new BillingDAO();

    public BillingPanel() {
        super("Billing",
              "Generate patient bills. Subtotal - discount = final payable amount.",
              new Field[]{
                Field.text("bill_id", "Bill ID"),
                Field.text("patient_id", "Patient ID"),
                Field.text("patient_name", "Patient Name"),
                Field.money("consultation_fee", "Consultation Fee"),
                Field.money("room_charges", "Room Charges"),
                Field.money("medicine_charges", "Medicine Charges"),
                Field.money("lab_charges", "Laboratory Charges"),
                Field.money("other_charges", "Other Charges"),
                Field.money("discount", "Discount (%)"),
                Field.money("total_amount", "Total Amount"),
                Field.combo("payment_status", "Payment Status", "Pending", "Paid", "Partially Paid"),
                Field.combo("payment_method", "Payment Method", "Cash", "Card", "UPI", "Insurance"),
                Field.date("bill_date", "Date")
              });
        clearForm();
        refresh("");
    }

    @Override protected BaseDAO<Bill> dao() { return dao; }
    @Override protected String idPrefix()   { return "B"; }
    @Override protected String addLabel()   { return "Save Bill"; }

    @Override
    protected Bill fromForm(Map<String, String> v) {
        Bill b = new Bill(v.get("bill_id"), v.get("patient_id"), v.get("patient_name"),
                UIUtils.toDouble(v.get("consultation_fee")), UIUtils.toDouble(v.get("room_charges")),
                UIUtils.toDouble(v.get("medicine_charges")), UIUtils.toDouble(v.get("lab_charges")),
                UIUtils.toDouble(v.get("other_charges")), UIUtils.toDouble(v.get("discount")),
                0, v.get("payment_status"), v.get("payment_method"), v.get("bill_date"));
        b.setTotalAmount(BillingService.total(b));      // always recalculated, never trusted from the form
        return b;
    }

    @Override
    protected void afterClear() {
        setValue("bill_date", UIUtils.today());
        for (String k : new String[]{ "consultation_fee", "room_charges", "medicine_charges",
                                      "lab_charges", "other_charges", "discount", "total_amount" }) {
            setValue(k, "0");
        }
    }

    @Override
    protected JButton[] extraButtons() {
        JButton generate = UIUtils.accent("Generate Bill", "money");
        generate.addActionListener(e -> generateBill());

        JButton print = UIUtils.ghost("Print Bill", "file");
        print.addActionListener(e -> printBill());

        JButton pending = UIUtils.ghost("Pending Bills", null);
        pending.addActionListener(e -> {
            try { setRows(dao.byStatus("Pending")); }
            catch (Exception ex) { UIUtils.error(this, "Could not filter bills.\n\n" + ex.getMessage()); }
        });
        return new JButton[]{ generate, print, pending };
    }

    /** Calculates the total from the charges typed in and shows the breakdown. */
    private void generateBill() {
        String problem = UIUtils.validate(fields, getValues());
        if (problem != null) { UIUtils.warn(this, problem); return; }

        Bill b = fromForm(getValues());
        setValue("total_amount", UIUtils.money(b.getTotalAmount()));
        UIUtils.textDialog(this, "Bill preview", BillingService.receipt(b));
    }

    private void printBill() {
        if (getValue("bill_id").isEmpty()) {
            UIUtils.warn(this, "Select or create a bill before printing.");
            return;
        }
        Bill b = fromForm(getValues());
        javax.swing.JTextArea area = new javax.swing.JTextArea(BillingService.receipt(b));
        area.setFont(new java.awt.Font(java.awt.Font.MONOSPACED, java.awt.Font.PLAIN, 12));
        try {
            boolean done = area.print();
            if (done) UIUtils.info(this, "Bill sent to the printer.");
        } catch (java.awt.print.PrinterException ex) {
            UIUtils.error(this, "Printing failed.\n\n" + ex.getMessage());
        }
    }
}
