package ui;

import dao.UserDAO;
import database.DBConnection;
import utils.Icons;
import utils.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.SQLException;

/** Entry screen. The dashboard only opens after a successful database login. */
public class LoginFrame extends JFrame {

    private final JTextField     userField = UIUtils.textField();
    private final JPasswordField passField = UIUtils.passwordField();
    private final char           echo      = passField.getEchoChar();
    private final UserDAO        userDAO   = new UserDAO();

    public LoginFrame() {
        setTitle(UIUtils.HOSPITAL_NAME + " - Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(940, 560);
        setMinimumSize(new Dimension(820, 520));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new GridLayout(1, 2));
        root.add(brandingSide());
        root.add(formSide());
        setContentPane(root);
        getRootPane().setDefaultButton(loginButton);
    }

    // ------------------------------------------------ left: hospital branding
    private JPanel brandingSide() {
        JPanel p = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, UIUtils.PRIMARY_DARK,
                                              getWidth(), getHeight(), UIUtils.ACCENT));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255, 255, 255, 26));
                g2.fillOval(-80, getHeight() - 220, 320, 320);
                g2.fillOval(getWidth() - 140, -90, 260, 260);
                g2.dispose();
            }
        };
        p.setOpaque(true);

        JPanel box = new JPanel();
        box.setOpaque(false);
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));

        JLabel logo = new JLabel(Icons.of("cross", 64, Color.WHITE));
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel name = UIUtils.label(UIUtils.HOSPITAL_NAME, 24, Font.BOLD, Color.WHITE);
        name.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel tag = UIUtils.label("Hospital Management System", 15, Font.PLAIN, new Color(226, 247, 250));
        tag.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel note = UIUtils.label("<html><div style='text-align:center;width:300px'>"
                + "Patients, doctors, appointments, billing, pharmacy and laboratory "
                + "in one secure desktop application.</div></html>", 13, Font.PLAIN, new Color(206, 240, 245));
        note.setAlignmentX(Component.CENTER_ALIGNMENT);

        box.add(logo);
        box.add(Box.createVerticalStrut(18));
        box.add(name);
        box.add(Box.createVerticalStrut(8));
        box.add(tag);
        box.add(Box.createVerticalStrut(22));
        box.add(note);
        p.add(box);
        return p;
    }

    // ------------------------------------------------------- right: the form
    private final JButton loginButton = UIUtils.primary("Login", null);

    private JPanel formSide() {
        JPanel wrap = new JPanel(new GridBagLayout());
        wrap.setBackground(Color.WHITE);

        JPanel form = new JPanel();
        form.setOpaque(false);
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBorder(new EmptyBorder(0, 40, 0, 40));
        form.setPreferredSize(new Dimension(380, 430));

        JLabel welcome = UIUtils.label("Welcome back", 26, Font.BOLD, UIUtils.TEXT);
        JLabel sub     = UIUtils.caption("Sign in to continue to the dashboard");
        welcome.setAlignmentX(Component.LEFT_ALIGNMENT);
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);

        userField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        passField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        JCheckBox show = new JCheckBox("Show password");
        show.setOpaque(false);
        show.setFont(UIUtils.regular(12));
        show.setForeground(UIUtils.MUTED);
        show.setAlignmentX(Component.LEFT_ALIGNMENT);
        show.addActionListener(e -> passField.setEchoChar(show.isSelected() ? (char) 0 : echo));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttons.setOpaque(false);
        buttons.setAlignmentX(Component.LEFT_ALIGNMENT);
        buttons.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));

        JButton clear = UIUtils.ghost("Clear", null);
        JButton exit  = UIUtils.ghost("Exit", null);
        loginButton.addActionListener(e -> doLogin());
        clear.addActionListener(e -> { userField.setText(""); passField.setText(""); userField.requestFocus(); });
        exit.addActionListener(e -> { DBConnection.close(); System.exit(0); });

        buttons.add(loginButton);
        buttons.add(clear);
        buttons.add(exit);

        form.add(welcome);
        form.add(Box.createVerticalStrut(6));
        form.add(sub);
        form.add(Box.createVerticalStrut(26));
        form.add(fieldLabel("Username"));
        form.add(userField);
        form.add(Box.createVerticalStrut(16));
        form.add(fieldLabel("Password"));
        form.add(passField);
        form.add(Box.createVerticalStrut(10));
        form.add(show);
        form.add(Box.createVerticalStrut(22));
        form.add(buttons);
        form.add(Box.createVerticalStrut(26));
        JLabel hint = UIUtils.caption("Demo login  -  username: admin   password: admin123");
        hint.setAlignmentX(Component.LEFT_ALIGNMENT);
        form.add(hint);

        wrap.add(form);
        return wrap;
    }

    private JLabel fieldLabel(String text) {
        JLabel l = UIUtils.label(text, 12, Font.BOLD, UIUtils.MUTED);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        l.setBorder(new EmptyBorder(0, 0, 6, 0));
        return l;
    }

    // ------------------------------------------------------------ login logic
    private void doLogin() {
        String user = userField.getText().trim();
        String pass = new String(passField.getPassword());

        if (user.isEmpty() || pass.isEmpty()) {
            UIUtils.warn(this, "Please enter both username and password.");
            return;
        }

        String dbProblem = DBConnection.testConnection();
        if (dbProblem != null) { UIUtils.error(this, dbProblem); return; }

        try {
            String display = userDAO.authenticate(user, pass);
            if (display == null) {
                UIUtils.warn(this, "Invalid username or password. Please try again.");
                passField.setText("");
                passField.requestFocus();
                return;
            }
            dispose();
            DashboardFrame dash = new DashboardFrame(display);
            dash.setVisible(true);
        } catch (SQLException ex) {
            UIUtils.error(this, "Login failed because of a database error.\n\n" + ex.getMessage());
        }
    }
}
