package ui;

import dao.AppointmentDAO;
import dao.BaseDAO;
import dao.ReportDAO;
import model.Appointment;
import utils.Field;
import utils.UIUtils;

import javax.swing.JButton;
import java.util.Map;

/** Appointment scheduling with status tracking. */
public class AppointmentPanel extends CrudPanel<Appointment> {

    private final AppointmentDAO dao = new AppointmentDAO();

    public AppointmentPanel() {
        super("Appointment Management",
              "Schedule, reschedule and cancel patient appointments.",
              buildFields());
        clearForm();
        refresh("");
    }

    private static Field[] buildFields() {
        String[] patients = ReportDAO.column(
                "SELECT CONCAT(patient_id,' - ',full_name) FROM patients ORDER BY patient_id");
        String[] doctors = ReportDAO.column(
                "SELECT CONCAT(doctor_id,' - ',name) FROM doctors ORDER BY doctor_id");
        return new Field[]{
            Field.text("appointment_id", "Appointment ID"),
            new Field("patient_id", "Patient", Field.Type.COMBO, true, patients),
            new Field("doctor_id", "Doctor", Field.Type.COMBO, true, doctors),
            Field.date("appt_date", "Date"),
            Field.time("appt_time", "Time"),
            Field.combo("department", "Department", "General Medicine", "Cardiology", "Neurology",
                    "Orthopedics", "Pediatrics", "Gynecology", "Emergency", "Radiology"),
            Field.text("reason", "Reason"),
            Field.combo("status", "Status", "Scheduled", "Completed", "Cancelled", "Emergency")
        };
    }

    @Override protected BaseDAO<Appointment> dao() { return dao; }
    @Override protected String idPrefix()          { return "A"; }
    @Override protected String addLabel()          { return "Schedule Appointment"; }

    /** Combos show "P001 - Rahul", the database only stores the id part. */
    private static String idOf(String comboValue) {
        if (comboValue == null) return "";
        int i = comboValue.indexOf(" - ");
        return i < 0 ? comboValue.trim() : comboValue.substring(0, i).trim();
    }

    @Override
    protected Appointment fromForm(Map<String, String> v) {
        return new Appointment(v.get("appointment_id"), idOf(v.get("patient_id")),
                idOf(v.get("doctor_id")), v.get("appt_date"), v.get("appt_time"),
                v.get("department"), v.get("reason"), v.get("status"));
    }

    @Override
    protected void afterClear() {
        setValue("appt_date", UIUtils.today());
        setValue("appt_time", "10:00");
    }

    @Override
    protected JButton[] extraButtons() {
        JButton cancel = UIUtils.button("Cancel Appointment", UIUtils.WARNING, java.awt.Color.WHITE, null);
        cancel.addActionListener(e -> changeStatus("Cancelled"));

        JButton complete = UIUtils.ghost("Mark Completed", null);
        complete.addActionListener(e -> changeStatus("Completed"));

        JButton todayOnly = UIUtils.ghost("Today Only", null);
        todayOnly.addActionListener(e -> {
            try { setRows(dao.onDate(UIUtils.today())); }
            catch (Exception ex) { UIUtils.error(this, "Could not load today's list.\n\n" + ex.getMessage()); }
        });
        return new JButton[]{ cancel, complete, todayOnly };
    }

    private void changeStatus(String status) {
        if (getValue("appointment_id").isEmpty()) {
            UIUtils.warn(this, "Select an appointment from the table first.");
            return;
        }
        setValue("status", status);
        onUpdate();
    }
}
