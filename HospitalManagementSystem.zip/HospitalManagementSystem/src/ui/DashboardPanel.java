package ui;

import dao.*;
import model.TableData;
import service.ClassificationService;
import utils.Icons;
import utils.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Landing screen: six statistic cards, five live tables and quick actions. */
public class DashboardPanel extends JPanel implements Refreshable {

    private final DashboardFrame frame;
    private final JPanel statsRow = new JPanel(new GridLayout(1, 6, 14, 14));
    private final JPanel gridRow  = new JPanel(new GridLayout(2, 3, 14, 14));

    private final PatientDAO     patients = new PatientDAO();
    private final DoctorDAO      doctors  = new DoctorDAO();
    private final AppointmentDAO appts    = new AppointmentDAO();
    private final BillingDAO     bills    = new BillingDAO();

    public DashboardPanel(DashboardFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout(0, 14));
        setBorder(new EmptyBorder(18, 18, 18, 18));
        setBackground(UIUtils.BG);

        statsRow.setOpaque(false);
        gridRow.setOpaque(false);

        JPanel body = new JPanel(new BorderLayout(0, 14));
        body.setOpaque(false);
        statsRow.setPreferredSize(new Dimension(10, 122));
        body.add(statsRow, BorderLayout.NORTH);
        body.add(gridRow, BorderLayout.CENTER);

        JScrollPane sp = new JScrollPane(body);
        sp.setBorder(null);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.getVerticalScrollBar().setUnitIncrement(18);
        add(sp, BorderLayout.CENTER);

        reload();
    }

    @Override
    public void reload() {
        statsRow.removeAll();
        gridRow.removeAll();

        int emergency = 0;
        try { emergency = patients.byPriority(ClassificationService.EMERGENCY).size(); }
        catch (Exception ignored) { }
        int freeBeds = Math.max(0, UIUtils.TOTAL_BEDS - patients.occupiedBeds());

        statsRow.add(statCard("Total Patients", String.valueOf(patients.count()),
                "registered in the hospital", "patients", UIUtils.PRIMARY, "Patients"));
        statsRow.add(statCard("Total Doctors", String.valueOf(doctors.count()),
                "across all departments", "doctors", UIUtils.ACCENT, "Doctors"));
        statsRow.add(statCard("Today's Appointments", String.valueOf(appts.countOn(UIUtils.today())),
                "scheduled for " + UIUtils.today(), "appointments", UIUtils.INFO, "Appointments"));
        statsRow.add(statCard("Pending Bills", String.valueOf(bills.pendingCount()),
                "Rs. " + UIUtils.money(bills.pendingAmount()) + " to collect", "billing",
                UIUtils.WARNING, "Billing"));
        statsRow.add(statCard("Available Beds", String.valueOf(freeBeds),
                "out of " + UIUtils.TOTAL_BEDS + " total beds", "bed", UIUtils.SUCCESS, "Patients"));
        statsRow.add(statCard("Emergency Cases", String.valueOf(emergency),
                "need immediate attention", "emergency", UIUtils.DANGER, "Patients"));

        gridRow.add(tableCard("Today's Appointments",
                "SELECT appointment_id AS 'ID', patient_id AS 'Patient', doctor_id AS 'Doctor', " +
                "appt_time AS 'Time', status AS 'Status' FROM appointments WHERE appt_date = ? " +
                "ORDER BY appt_time", UIUtils.today()));

        gridRow.add(tableCard("Patient Priority (rule-based)",
                "SELECT patient_id AS 'ID', full_name AS 'Patient', age AS 'Age', " +
                "priority AS 'Priority', disease AS 'Problem' FROM patients " +
                "ORDER BY FIELD(priority,'Emergency','High Priority','Medium Priority','Low Priority'), " +
                "patient_id LIMIT 12"));

        gridRow.add(tableCard("Recent Patients",
                "SELECT patient_id AS 'ID', full_name AS 'Name', admission_date AS 'Admitted', " +
                "room_no AS 'Room', doctor AS 'Doctor' FROM patients ORDER BY admission_date DESC LIMIT 12"));

        gridRow.add(tableCard("Recent Billing Activity",
                "SELECT bill_id AS 'Bill', patient_name AS 'Patient', total_amount AS 'Total', " +
                "payment_status AS 'Status', bill_date AS 'Date' FROM bills ORDER BY bill_date DESC LIMIT 12"));

        gridRow.add(tableCard("Available Doctors",
                "SELECT doctor_id AS 'ID', name AS 'Doctor', specialization AS 'Department', " +
                "room_no AS 'Room' FROM doctors WHERE availability = 'Available'"));

        gridRow.add(quickActions());

        revalidate();
        repaint();
    }

    // ------------------------------------------------------------ components

    private JPanel statCard(String title, String value, String desc, String icon,
                            final Color accent, final String opens) {
        JPanel card = UIUtils.roundPanel(UIUtils.CARD, 16);
        card.setBorder(new EmptyBorder(14, 16, 14, 16));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        card.setToolTipText("Open " + opens);

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(UIUtils.label(title, 12, Font.BOLD, UIUtils.MUTED), BorderLayout.WEST);

        JLabel badge = new JLabel(Icons.of(icon, 20, accent));
        badge.setBorder(new EmptyBorder(0, 6, 0, 0));
        top.add(badge, BorderLayout.EAST);

        JPanel mid = new JPanel();
        mid.setOpaque(false);
        mid.setLayout(new BoxLayout(mid, BoxLayout.Y_AXIS));
        JLabel big = UIUtils.label(value, 30, Font.BOLD, accent);
        big.setAlignmentX(LEFT_ALIGNMENT);
        JLabel small = UIUtils.caption(desc);
        small.setAlignmentX(LEFT_ALIGNMENT);
        mid.add(Box.createVerticalStrut(6));
        mid.add(big);
        mid.add(Box.createVerticalStrut(2));
        mid.add(small);

        card.add(top, BorderLayout.NORTH);
        card.add(mid, BorderLayout.CENTER);
        card.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { frame.openModule(opens); }
        });
        return card;
    }

    private JPanel tableCard(String heading, String sql, Object... args) {
        JPanel card = UIUtils.card(heading);
        JTable t;
        try {
            TableData d = ReportDAO.run(sql, args);
            t = new JTable(new DefaultTableModel(d.matrix(), d.columns) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            });
        } catch (Exception ex) {
            t = new JTable(new DefaultTableModel(new Object[][]{{ "Could not load data" }},
                                                 new Object[]{ "Message" }));
        }
        JScrollPane sp = UIUtils.styledTable(t);
        sp.setPreferredSize(new Dimension(320, 210));
        card.add(sp, BorderLayout.CENTER);
        return card;
    }

    private JPanel quickActions() {
        JPanel card = UIUtils.card("Quick Actions");
        JPanel grid = new JPanel(new GridLayout(0, 1, 0, 8));
        grid.setOpaque(false);

        grid.add(action("Register New Patient", "patients", "Patients"));
        grid.add(action("Schedule Appointment", "appointments", "Appointments"));
        grid.add(action("Generate a Bill", "billing", "Billing"));
        grid.add(action("Check Pharmacy Stock", "pharmacy", "Pharmacy"));
        grid.add(action("Open Reports", "reports", "Reports"));

        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.add(grid, BorderLayout.NORTH);
        card.add(wrap, BorderLayout.CENTER);
        return card;
    }

    private JButton action(String text, String icon, final String module) {
        JButton b = UIUtils.ghost(text, icon);
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.addActionListener(e -> frame.openModule(module));
        return b;
    }
}
