package ui;

/** Any screen that should reload its data when it becomes visible. */
public interface Refreshable {
    void reload();
}
