package ui;

import database.DBConnection;
import utils.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** Application information and a database connectivity check. */
public class SettingsPanel extends JPanel implements Refreshable {

    private final JLabel dbState = UIUtils.caption("Not checked yet");

    public SettingsPanel(String user) {
        setLayout(new BorderLayout(0, 14));
        setBorder(new EmptyBorder(18, 18, 18, 18));
        setBackground(UIUtils.BG);

        JPanel card = UIUtils.card("Settings");
        JPanel body = new JPanel(new GridLayout(0, 2, 18, 12));
        body.setOpaque(false);

        body.add(info("Hospital", UIUtils.HOSPITAL_NAME));
        body.add(info("Signed in as", user));
        body.add(info("Database", "MySQL  -  hospital_db"));
        body.add(info("Connectivity", "JDBC with PreparedStatement"));
        body.add(info("Total beds configured", String.valueOf(UIUtils.TOTAL_BEDS)));
        body.add(info("Classification", "Rule-based priority engine"));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttons.setOpaque(false);
        buttons.setBorder(new EmptyBorder(16, 0, 0, 0));

        JButton test = UIUtils.primary("Test Database Connection", null);
        test.addActionListener(e -> {
            String problem = DBConnection.testConnection();
            if (problem == null) {
                dbState.setText("Connected successfully");
                dbState.setForeground(UIUtils.SUCCESS);
                UIUtils.info(this, "Database connection is working.");
            } else {
                dbState.setText("Not connected");
                dbState.setForeground(UIUtils.DANGER);
                UIUtils.error(this, problem);
            }
        });

        JButton about = UIUtils.ghost("About this software", null);
        about.addActionListener(e -> UIUtils.textDialog(this, "About",
                UIUtils.HOSPITAL_NAME + "\nHospital Management System\n\n" +
                "Built with Java Swing and MySQL (JDBC).\n" +
                "Architecture: UI  ->  Service  ->  DAO  ->  MySQL\n\n" +
                "Modules: Patients, Doctors, Appointments, Medical Records,\n" +
                "Billing, Pharmacy, Laboratory, Staff and Reports.\n\n" +
                "Patient priority uses a rule-based classification system\n" +
                "(see service/ClassificationService.java)."));

        buttons.add(test);
        buttons.add(about);

        JPanel state = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        state.setOpaque(false);
        state.add(UIUtils.label("Connection status:", 12, Font.BOLD, UIUtils.MUTED));
        state.add(dbState);

        JPanel south = new JPanel(new BorderLayout(0, 8));
        south.setOpaque(false);
        south.add(buttons, BorderLayout.NORTH);
        south.add(state, BorderLayout.SOUTH);

        card.add(body, BorderLayout.CENTER);
        card.add(south, BorderLayout.SOUTH);
        add(card, BorderLayout.NORTH);
    }

    private JPanel info(String key, String value) {
        JPanel p = new JPanel(new BorderLayout(0, 3));
        p.setOpaque(false);
        p.add(UIUtils.label(key, 12, Font.BOLD, UIUtils.MUTED), BorderLayout.NORTH);
        p.add(UIUtils.label(value, 14, Font.PLAIN, UIUtils.TEXT), BorderLayout.CENTER);
        return p;
    }

    @Override public void reload() { }
}
