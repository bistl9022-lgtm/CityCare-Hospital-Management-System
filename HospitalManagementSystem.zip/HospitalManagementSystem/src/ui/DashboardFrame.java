package ui;

import dao.AppointmentDAO;
import dao.BillingDAO;
import dao.MedicineDAO;
import dao.PatientDAO;
import model.TableData;
import service.ClassificationService;
import service.SearchService;
import utils.Icons;
import utils.UIUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedHashMap;
import java.util.Map;

/** The main window: fixed sidebar + header, and a content area that swaps panels. */
public class DashboardFrame extends JFrame {

    private static final String[][] MENU = {
        { "Dashboard",       "dashboard"    },
        { "Patients",        "patients"     },
        { "Doctors",         "doctors"      },
        { "Appointments",    "appointments" },
        { "Medical Records", "records"      },
        { "Billing",         "billing"      },
        { "Pharmacy",        "pharmacy"     },
        { "Laboratory",      "laboratory"   },
        { "Staff",           "staff"        },
        { "Reports",         "reports"      },
        { "Settings",        "settings"     },
        { "Logout",          "logout"       }
    };

    private final String     currentUser;
    private final CardLayout cards   = new CardLayout();
    private final JPanel     content = new JPanel(cards);
    private final Map<String, JPanel>  created = new LinkedHashMap<String, JPanel>();
    private final Map<String, JButton> navButtons = new LinkedHashMap<String, JButton>();

    private final JLabel pageTitle = UIUtils.label("Dashboard", 19, Font.BOLD, UIUtils.TEXT);
    private final JLabel clock     = UIUtils.caption(UIUtils.nowStamp());
    private final JTextField globalSearch = UIUtils.textField();

    public DashboardFrame(String user) {
        this.currentUser = user;

        setTitle(UIUtils.HOSPITAL_NAME + " - Hospital Management System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1420, 850);
        setMinimumSize(new Dimension(1120, 700));
        setLocationRelativeTo(null);

        content.setBackground(UIUtils.BG);

        JPanel right = new JPanel(new BorderLayout());
        right.setBackground(UIUtils.BG);
        right.add(buildHeader(), BorderLayout.NORTH);
        right.add(content, BorderLayout.CENTER);

        JPanel root = new JPanel(new BorderLayout());
        root.add(buildSidebar(), BorderLayout.WEST);
        root.add(right, BorderLayout.CENTER);
        setContentPane(root);

        show("Dashboard");

        new Timer(1000, e -> clock.setText(UIUtils.nowStamp())).start();
    }

    // ===================================================== sidebar

    private JPanel buildSidebar() {
        JPanel bar = new JPanel();
        bar.setLayout(new BoxLayout(bar, BoxLayout.Y_AXIS));
        bar.setBackground(UIUtils.SIDEBAR);
        bar.setPreferredSize(new Dimension(236, 100));
        bar.setBorder(new EmptyBorder(22, 14, 18, 14));

        JPanel logoRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        logoRow.setOpaque(false);
        logoRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 54));
        logoRow.add(new JLabel(Icons.of("cross", 30, UIUtils.ACCENT)));
        JPanel names = new JPanel();
        names.setOpaque(false);
        names.setLayout(new BoxLayout(names, BoxLayout.Y_AXIS));
        names.add(UIUtils.label("City Care", 16, Font.BOLD, Color.WHITE));
        names.add(UIUtils.label("Hospital Suite", 11, Font.PLAIN, new Color(148, 183, 194)));
        logoRow.add(names);
        bar.add(logoRow);
        bar.add(Box.createVerticalStrut(22));

        for (String[] item : MENU) {
            if (item[0].equals("Logout")) bar.add(Box.createVerticalGlue());
            JButton b = navButton(item[0], item[1]);
            navButtons.put(item[0], b);
            bar.add(b);
            bar.add(Box.createVerticalStrut(4));
        }
        return bar;
    }

    private JButton navButton(final String name, String icon) {
        final JButton b = new JButton(name);
        b.setIcon(Icons.of(icon, 17, new Color(160, 200, 212)));
        b.setIconTextGap(12);
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setFont(UIUtils.font(13, Font.BOLD));
        b.setForeground(new Color(206, 226, 234));
        b.setBackground(UIUtils.SIDEBAR);
        b.setOpaque(true);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(11, 14, 11, 14));
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                if (!Boolean.TRUE.equals(b.getClientProperty("active")))
                    b.setBackground(UIUtils.SIDEBAR_HOVER);
            }
            @Override public void mouseExited(MouseEvent e) {
                if (!Boolean.TRUE.equals(b.getClientProperty("active")))
                    b.setBackground(UIUtils.SIDEBAR);
            }
        });
        b.addActionListener(e -> {
            if (name.equals("Logout")) logout(); else show(name);
        });
        return b;
    }

    private void markActive(String name) {
        for (Map.Entry<String, JButton> e : navButtons.entrySet()) {
            boolean active = e.getKey().equals(name);
            e.getValue().putClientProperty("active", active);
            e.getValue().setBackground(active ? UIUtils.PRIMARY : UIUtils.SIDEBAR);
            e.getValue().setForeground(active ? Color.WHITE : new Color(206, 226, 234));
        }
    }

    // ===================================================== header

    private JPanel buildHeader() {
        JPanel h = new JPanel(new BorderLayout(16, 0));
        h.setBackground(Color.WHITE);
        h.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UIUtils.BORDER),
                new EmptyBorder(14, 22, 14, 22)));

        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        JLabel hospital = UIUtils.label(UIUtils.HOSPITAL_NAME, 12, Font.BOLD, UIUtils.PRIMARY);
        hospital.setAlignmentX(Component.LEFT_ALIGNMENT);
        pageTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        left.add(hospital);
        left.add(pageTitle);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setOpaque(false);

        globalSearch.setPreferredSize(new Dimension(260, 36));
        globalSearch.setToolTipText("Search patients, doctors, appointments and bills");
        globalSearch.addActionListener(e -> runGlobalSearch());
        JButton searchBtn = UIUtils.primary("Search", "search");
        searchBtn.addActionListener(e -> runGlobalSearch());

        JButton bell = UIUtils.ghost("", "bell");
        bell.setToolTipText("Notifications");
        bell.addActionListener(e -> showNotifications());

        JPanel profile = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        profile.setOpaque(false);
        JLabel avatar = new JLabel(Icons.of("user", 22, UIUtils.PRIMARY));
        JPanel who = new JPanel();
        who.setOpaque(false);
        who.setLayout(new BoxLayout(who, BoxLayout.Y_AXIS));
        who.add(UIUtils.label(currentUser, 12, Font.BOLD, UIUtils.TEXT));
        who.add(clock);
        profile.add(avatar);
        profile.add(who);

        right.add(globalSearch);
        right.add(searchBtn);
        right.add(bell);
        right.add(profile);

        h.add(left, BorderLayout.WEST);
        h.add(right, BorderLayout.EAST);
        return h;
    }

    // ===================================================== navigation

    /** Creates the panel the first time it is opened, then just shows it. */
    public void show(String name) {
        if (!created.containsKey(name)) {
            JPanel p = createPanel(name);
            created.put(name, p);
            content.add(p, name);
        }
        JPanel p = created.get(name);
        if (p instanceof Refreshable) ((Refreshable) p).reload();
        cards.show(content, name);
        pageTitle.setText(name);
        markActive(name);
    }

    private JPanel createPanel(String name) {
        if (name.equals("Dashboard"))       return new DashboardPanel(this);
        if (name.equals("Patients"))        return new PatientPanel();
        if (name.equals("Doctors"))         return new DoctorPanel();
        if (name.equals("Appointments"))    return new AppointmentPanel();
        if (name.equals("Medical Records")) return new MedicalRecordPanel();
        if (name.equals("Billing"))         return new BillingPanel();
        if (name.equals("Pharmacy"))        return new PharmacyPanel();
        if (name.equals("Laboratory"))      return new LaboratoryPanel();
        if (name.equals("Staff"))           return new StaffPanel();
        if (name.equals("Reports"))         return new ReportsPanel();
        return new SettingsPanel(currentUser);
    }

    private void logout() {
        if (!UIUtils.confirm(this, "Do you want to logout?")) return;
        dispose();
        new LoginFrame().setVisible(true);
    }

    // ===================================================== header actions

    private void runGlobalSearch() {
        String key = globalSearch.getText().trim();
        if (key.isEmpty()) { UIUtils.warn(this, "Type something to search for."); return; }
        try {
            Map<String, TableData> results = SearchService.searchEverywhere(key);
            JTabbedPane tabs = new JTabbedPane();
            int total = 0;
            for (Map.Entry<String, TableData> e : results.entrySet()) {
                TableData d = e.getValue();
                total += d.size();
                JTable t = new JTable(new DefaultTableModel(d.matrix(), d.columns) {
                    @Override public boolean isCellEditable(int r, int c) { return false; }
                });
                tabs.addTab(e.getKey() + " (" + d.size() + ")", UIUtils.styledTable(t));
            }
            tabs.setPreferredSize(new Dimension(860, 420));
            JOptionPane.showMessageDialog(this, tabs,
                    "Search results for \"" + key + "\"  -  " + total + " match(es)",
                    JOptionPane.PLAIN_MESSAGE);
        } catch (Exception ex) {
            UIUtils.error(this, "Search failed.\n\n" + ex.getMessage());
        }
    }

    private void showNotifications() {
        StringBuilder sb = new StringBuilder();
        try {
            int appts     = new AppointmentDAO().countOn(UIUtils.today());
            int emergency = new PatientDAO().byPriority(ClassificationService.EMERGENCY).size();
            int lowStock  = new MedicineDAO().lowStockCount();
            BillingDAO bills = new BillingDAO();

            sb.append("Today's appointments        : ").append(appts).append('\n');
            sb.append("Emergency priority patients : ").append(emergency).append('\n');
            sb.append("Medicines low on stock      : ").append(lowStock).append('\n');
            sb.append("Unpaid bills                : ").append(bills.pendingCount())
              .append("  (Rs. ").append(UIUtils.money(bills.pendingAmount())).append(")\n");
            sb.append("Expired medicines           : ")
              .append(new MedicineDAO().expired(UIUtils.today()).size()).append('\n');
        } catch (Exception ex) {
            sb.append("Could not load notifications:\n").append(ex.getMessage());
        }
        UIUtils.textDialog(this, "Notifications", sb.toString());
    }

    /** Called by the Dashboard cards so their buttons can open other modules. */
    public void openModule(String name) { show(name); }
}
