package ui;

import dao.BaseDAO;
import dao.DoctorDAO;
import model.Doctor;
import utils.Field;
import utils.UIUtils;

import javax.swing.JButton;
import java.util.Map;

/** Doctor directory: specialisation, availability and consulting room. */
public class DoctorPanel extends CrudPanel<Doctor> {

    private final DoctorDAO dao = new DoctorDAO();

    public DoctorPanel() {
        super("Doctor Management",
              "Maintain the list of doctors, their departments and availability.",
              new Field[]{
                Field.text("doctor_id", "Doctor ID"),
                Field.text("name", "Name"),
                Field.combo("specialization", "Specialization", "General Medicine", "Cardiology",
                        "Neurology", "Orthopedics", "Pediatrics", "Gynecology", "Dermatology",
                        "ENT", "Oncology", "Psychiatry"),
                Field.combo("gender", "Gender", "Male", "Female", "Other"),
                Field.phone("phone", "Phone"),
                Field.email("email", "Email"),
                Field.num("experience", "Experience (years)"),
                Field.text("qualification", "Qualification"),
                Field.combo("availability", "Availability", "Available", "On Leave", "In Surgery", "Off Duty"),
                Field.opt("room_no", "Room Number")
              });
        clearForm();
        refresh("");
    }

    @Override protected BaseDAO<Doctor> dao() { return dao; }
    @Override protected String idPrefix()     { return "D"; }

    @Override
    protected Doctor fromForm(Map<String, String> v) {
        return new Doctor(v.get("doctor_id"), v.get("name"), v.get("specialization"), v.get("gender"),
                v.get("phone"), v.get("email"), UIUtils.toInt(v.get("experience")),
                v.get("qualification"), v.get("availability"), v.get("room_no"));
    }

    @Override
    protected JButton[] extraButtons() {
        JButton avail = UIUtils.ghost("Available Only", null);
        avail.addActionListener(e -> {
            try { setRows(dao.available()); }
            catch (Exception ex) { UIUtils.error(this, "Could not filter doctors.\n\n" + ex.getMessage()); }
        });
        return new JButton[]{ avail };
    }
}
