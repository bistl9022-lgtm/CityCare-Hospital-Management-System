package ui;

import dao.BaseDAO;
import dao.PatientDAO;
import dao.ReportDAO;
import model.Patient;
import service.ClassificationService;
import utils.Field;
import utils.UIUtils;

import javax.swing.*;
import java.util.Map;

/** Patient registration, editing and rule-based priority classification. */
public class PatientPanel extends CrudPanel<Patient> {

    private static final String AUTO = "Auto (rule-based)";
    private final PatientDAO dao = new PatientDAO();

    public PatientPanel() {
        super("Patient Management",
              "Register patients, update their details and classify treatment priority.",
              buildFields());
        clearForm();
        refresh("");
    }

    private static Field[] buildFields() {
        String[] doctors = ReportDAO.column("SELECT name FROM doctors ORDER BY name", "Not assigned");
        return new Field[]{
            Field.text("patient_id", "Patient ID"),
            Field.text("full_name", "Full Name"),
            Field.num("age", "Age"),
            Field.combo("gender", "Gender", "Male", "Female", "Other"),
            Field.date("dob", "Date of Birth"),
            Field.phone("phone", "Phone"),
            Field.email("email", "Email"),
            Field.opt("address", "Address"),
            Field.combo("blood_group", "Blood Group", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"),
            Field.phone("emergency_contact", "Emergency Contact"),
            Field.text("disease", "Disease / Problem"),
            Field.date("admission_date", "Admission Date"),
            Field.opt("room_no", "Room Number"),
            new Field("doctor", "Doctor", Field.Type.COMBO, true, doctors),
            Field.combo("priority", "Priority", AUTO, ClassificationService.EMERGENCY,
                    ClassificationService.HIGH, ClassificationService.MEDIUM, ClassificationService.LOW)
        };
    }

    @Override protected BaseDAO<Patient> dao() { return dao; }
    @Override protected String idPrefix()      { return "P"; }

    @Override
    protected Patient fromForm(Map<String, String> v) {
        int age = UIUtils.toInt(v.get("age"));
        String priority = v.get("priority");
        if (AUTO.equals(priority)) {
            priority = ClassificationService.classify(age, v.get("disease"), false, null).level;
        }
        return new Patient(
                v.get("patient_id"), v.get("full_name"), age, v.get("gender"), v.get("dob"),
                v.get("phone"), v.get("email"), v.get("address"), v.get("blood_group"),
                v.get("emergency_contact"), v.get("disease"), v.get("admission_date"),
                v.get("room_no"), v.get("doctor"), priority);
    }

    @Override
    protected void afterClear() {
        setValue("admission_date", UIUtils.today());
    }

    @Override
    protected JButton[] extraButtons() {
        JButton classify = UIUtils.button("Classify Patient", UIUtils.WARNING, java.awt.Color.WHITE, "emergency");
        classify.addActionListener(e -> classifyCurrentPatient());

        JButton emergencyOnly = UIUtils.ghost("Emergency List", null);
        emergencyOnly.addActionListener(e -> {
            try { setRows(dao.byPriority(ClassificationService.EMERGENCY)); }
            catch (Exception ex) { UIUtils.error(this, "Could not load emergency patients.\n\n" + ex.getMessage()); }
        });
        return new JButton[]{ classify, emergencyOnly };
    }

    /** Runs the rule engine on whatever is typed in the form and explains the result. */
    private void classifyCurrentPatient() {
        Map<String, String> v = getValues();
        if (v.get("disease").isEmpty()) {
            UIUtils.warn(this, "Enter the disease / problem first so it can be classified.");
            return;
        }
        boolean emergencyCase = JOptionPane.showConfirmDialog(this,
                "Was this patient brought in as an emergency case?",
                "Classification input", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;

        String manual = v.get("priority");
        ClassificationService.Result r = ClassificationService.classify(
                UIUtils.toInt(v.get("age")), v.get("disease"), emergencyCase,
                AUTO.equals(manual) ? null : manual);

        setValue("priority", r.level);
        UIUtils.textDialog(this, "Rule-based classification",
                "Patient : " + (v.get("full_name").isEmpty() ? "(new patient)" : v.get("full_name")) + "\n" +
                "Age     : " + v.get("age") + "\n" +
                "Problem : " + v.get("disease") + "\n\n" +
                "Rules applied\n-------------\n" + r.reason + "\n\n" +
                "Result  : " + r.level + "\n" +
                "Action  : " + r.action() + "\n\n" +
                "Press Add or Update to save this priority.");
    }
}
