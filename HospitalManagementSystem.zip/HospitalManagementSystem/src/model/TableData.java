package model;

import java.util.ArrayList;
import java.util.List;

/** Plain carrier for "columns + rows" used by reports and global search. */
public class TableData {
    public final String[] columns;
    public final List<Object[]> rows = new ArrayList<>();

    public TableData(String... columns) { this.columns = columns; }

    public Object[][] matrix() { return rows.toArray(new Object[0][]); }
    public int size() { return rows.size(); }
}
