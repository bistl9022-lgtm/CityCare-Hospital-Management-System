package model;

/** Data holder for one staff record. */
public class Staff implements Entity {

    private String staffId;
    private String name;
    private String role;
    private String department;
    private String phone;
    private String email;
    private double salary;
    private String joiningDate;
    private String shift;

    public Staff(String staffId, String name, String role, String department, String phone, String email, double salary, String joiningDate, String shift) {
        this.staffId = staffId;
        this.name = name;
        this.role = role;
        this.department = department;
        this.phone = phone;
        this.email = email;
        this.salary = salary;
        this.joiningDate = joiningDate;
        this.shift = shift;
    }

    public String getStaffId() { return staffId; }
    public String getName() { return name; }
    public String getRole() { return role; }
    public String getDepartment() { return department; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
    public double getSalary() { return salary; }
    public String getJoiningDate() { return joiningDate; }
    public String getShift() { return shift; }

    @Override public String id() { return staffId; }

    @Override public Object[] toRow() {
        return new Object[]{ staffId, name, role, department, phone, email, salary, joiningDate, shift };
    }
}
