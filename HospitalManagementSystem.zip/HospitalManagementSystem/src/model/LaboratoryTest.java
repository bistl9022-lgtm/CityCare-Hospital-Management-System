package model;

/** Data holder for one laboratorytest record. */
public class LaboratoryTest implements Entity {

    private String testId;
    private String patientId;
    private String patientName;
    private String testName;
    private String doctor;
    private String testDate;
    private String result;
    private String status;
    private double cost;

    public LaboratoryTest(String testId, String patientId, String patientName, String testName, String doctor, String testDate, String result, String status, double cost) {
        this.testId = testId;
        this.patientId = patientId;
        this.patientName = patientName;
        this.testName = testName;
        this.doctor = doctor;
        this.testDate = testDate;
        this.result = result;
        this.status = status;
        this.cost = cost;
    }

    public String getTestId() { return testId; }
    public String getPatientId() { return patientId; }
    public String getPatientName() { return patientName; }
    public String getTestName() { return testName; }
    public String getDoctor() { return doctor; }
    public String getTestDate() { return testDate; }
    public String getResult() { return result; }
    public String getStatus() { return status; }
    public double getCost() { return cost; }
    public void setResult(String result) { this.result = result; }
    public void setStatus(String status) { this.status = status; }

    @Override public String id() { return testId; }

    @Override public Object[] toRow() {
        return new Object[]{ testId, patientId, patientName, testName, doctor, testDate, result, status, cost };
    }
}
