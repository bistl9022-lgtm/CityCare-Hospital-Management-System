package model;

/** Data holder for one appointment record. */
public class Appointment implements Entity {

    private String appointmentId;
    private String patientId;
    private String doctorId;
    private String date;
    private String time;
    private String department;
    private String reason;
    private String status;

    public Appointment(String appointmentId, String patientId, String doctorId, String date, String time, String department, String reason, String status) {
        this.appointmentId = appointmentId;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.date = date;
        this.time = time;
        this.department = department;
        this.reason = reason;
        this.status = status;
    }

    public String getAppointmentId() { return appointmentId; }
    public String getPatientId() { return patientId; }
    public String getDoctorId() { return doctorId; }
    public String getDate() { return date; }
    public String getTime() { return time; }
    public String getDepartment() { return department; }
    public String getReason() { return reason; }
    public String getStatus() { return status; }

    @Override public String id() { return appointmentId; }

    @Override public Object[] toRow() {
        return new Object[]{ appointmentId, patientId, doctorId, date, time, department, reason, status };
    }
}
