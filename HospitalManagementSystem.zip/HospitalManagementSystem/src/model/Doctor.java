package model;

/** Data holder for one doctor record. */
public class Doctor implements Entity {

    private String doctorId;
    private String name;
    private String specialization;
    private String gender;
    private String phone;
    private String email;
    private int experience;
    private String qualification;
    private String availability;
    private String roomNo;

    public Doctor(String doctorId, String name, String specialization, String gender, String phone, String email, int experience, String qualification, String availability, String roomNo) {
        this.doctorId = doctorId;
        this.name = name;
        this.specialization = specialization;
        this.gender = gender;
        this.phone = phone;
        this.email = email;
        this.experience = experience;
        this.qualification = qualification;
        this.availability = availability;
        this.roomNo = roomNo;
    }

    public String getDoctorId() { return doctorId; }
    public String getName() { return name; }
    public String getSpecialization() { return specialization; }
    public String getGender() { return gender; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
    public int getExperience() { return experience; }
    public String getQualification() { return qualification; }
    public String getAvailability() { return availability; }
    public String getRoomNo() { return roomNo; }

    @Override public String id() { return doctorId; }

    @Override public Object[] toRow() {
        return new Object[]{ doctorId, name, specialization, gender, phone, email, experience, qualification, availability, roomNo };
    }
}
