package model;

/** Data holder for one patient record. */
public class Patient implements Entity {

    private String patientId;
    private String fullName;
    private int age;
    private String gender;
    private String dob;
    private String phone;
    private String email;
    private String address;
    private String bloodGroup;
    private String emergencyContact;
    private String disease;
    private String admissionDate;
    private String roomNo;
    private String doctor;
    private String priority;

    public Patient(String patientId, String fullName, int age, String gender, String dob, String phone, String email, String address, String bloodGroup, String emergencyContact, String disease, String admissionDate, String roomNo, String doctor, String priority) {
        this.patientId = patientId;
        this.fullName = fullName;
        this.age = age;
        this.gender = gender;
        this.dob = dob;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.bloodGroup = bloodGroup;
        this.emergencyContact = emergencyContact;
        this.disease = disease;
        this.admissionDate = admissionDate;
        this.roomNo = roomNo;
        this.doctor = doctor;
        this.priority = priority;
    }

    public String getPatientId() { return patientId; }
    public String getFullName() { return fullName; }
    public int getAge() { return age; }
    public String getGender() { return gender; }
    public String getDob() { return dob; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
    public String getAddress() { return address; }
    public String getBloodGroup() { return bloodGroup; }
    public String getEmergencyContact() { return emergencyContact; }
    public String getDisease() { return disease; }
    public String getAdmissionDate() { return admissionDate; }
    public String getRoomNo() { return roomNo; }
    public String getDoctor() { return doctor; }
    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }

    @Override public String id() { return patientId; }

    @Override public Object[] toRow() {
        return new Object[]{ patientId, fullName, age, gender, dob, phone, email, address, bloodGroup, emergencyContact, disease, admissionDate, roomNo, doctor, priority };
    }
}
