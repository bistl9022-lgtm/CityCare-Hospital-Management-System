package model;

/** Data holder for one medicalrecord record. */
public class MedicalRecord implements Entity {

    private String recordId;
    private String patientId;
    private String doctorId;
    private String diagnosis;
    private String symptoms;
    private String treatment;
    private String prescription;
    private String testResults;
    private String notes;
    private String date;

    public MedicalRecord(String recordId, String patientId, String doctorId, String diagnosis, String symptoms, String treatment, String prescription, String testResults, String notes, String date) {
        this.recordId = recordId;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.diagnosis = diagnosis;
        this.symptoms = symptoms;
        this.treatment = treatment;
        this.prescription = prescription;
        this.testResults = testResults;
        this.notes = notes;
        this.date = date;
    }

    public String getRecordId() { return recordId; }
    public String getPatientId() { return patientId; }
    public String getDoctorId() { return doctorId; }
    public String getDiagnosis() { return diagnosis; }
    public String getSymptoms() { return symptoms; }
    public String getTreatment() { return treatment; }
    public String getPrescription() { return prescription; }
    public String getTestResults() { return testResults; }
    public String getNotes() { return notes; }
    public String getDate() { return date; }

    @Override public String id() { return recordId; }

    @Override public Object[] toRow() {
        return new Object[]{ recordId, patientId, doctorId, diagnosis, symptoms, treatment, prescription, testResults, notes, date };
    }
}
