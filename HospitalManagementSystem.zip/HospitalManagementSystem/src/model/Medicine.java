package model;

/** Data holder for one medicine record. */
public class Medicine implements Entity {

    private String medicineId;
    private String name;
    private String category;
    private int quantity;
    private double price;
    private String expiryDate;
    private String supplier;

    public Medicine(String medicineId, String name, String category, int quantity, double price, String expiryDate, String supplier) {
        this.medicineId = medicineId;
        this.name = name;
        this.category = category;
        this.quantity = quantity;
        this.price = price;
        this.expiryDate = expiryDate;
        this.supplier = supplier;
    }

    public String getMedicineId() { return medicineId; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public int getQuantity() { return quantity; }
    public double getPrice() { return price; }
    public String getExpiryDate() { return expiryDate; }
    public String getSupplier() { return supplier; }

    @Override public String id() { return medicineId; }

    @Override public Object[] toRow() {
        return new Object[]{ medicineId, name, category, quantity, price, expiryDate, supplier };
    }
}
