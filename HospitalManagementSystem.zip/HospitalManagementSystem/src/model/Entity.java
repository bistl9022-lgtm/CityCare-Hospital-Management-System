package model;

/** Anything that can be shown as one row of a JTable. */
public interface Entity {
    /** Values in exactly the same order as the form fields of its panel. */
    Object[] toRow();
    /** Primary key value. */
    String id();
}
