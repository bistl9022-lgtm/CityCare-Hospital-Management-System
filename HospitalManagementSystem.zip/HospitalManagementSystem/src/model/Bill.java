package model;

/** Data holder for one bill record. */
public class Bill implements Entity {

    private String billId;
    private String patientId;
    private String patientName;
    private double consultationFee;
    private double roomCharges;
    private double medicineCharges;
    private double labCharges;
    private double otherCharges;
    private double discount;
    private double totalAmount;
    private String paymentStatus;
    private String paymentMethod;
    private String date;

    public Bill(String billId, String patientId, String patientName, double consultationFee, double roomCharges, double medicineCharges, double labCharges, double otherCharges, double discount, double totalAmount, String paymentStatus, String paymentMethod, String date) {
        this.billId = billId;
        this.patientId = patientId;
        this.patientName = patientName;
        this.consultationFee = consultationFee;
        this.roomCharges = roomCharges;
        this.medicineCharges = medicineCharges;
        this.labCharges = labCharges;
        this.otherCharges = otherCharges;
        this.discount = discount;
        this.totalAmount = totalAmount;
        this.paymentStatus = paymentStatus;
        this.paymentMethod = paymentMethod;
        this.date = date;
    }

    public String getBillId() { return billId; }
    public String getPatientId() { return patientId; }
    public String getPatientName() { return patientName; }
    public double getConsultationFee() { return consultationFee; }
    public double getRoomCharges() { return roomCharges; }
    public double getMedicineCharges() { return medicineCharges; }
    public double getLabCharges() { return labCharges; }
    public double getOtherCharges() { return otherCharges; }
    public double getDiscount() { return discount; }
    public double getTotalAmount() { return totalAmount; }
    public String getPaymentStatus() { return paymentStatus; }
    public String getPaymentMethod() { return paymentMethod; }
    public String getDate() { return date; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }

    @Override public String id() { return billId; }

    @Override public Object[] toRow() {
        return new Object[]{ billId, patientId, patientName, consultationFee, roomCharges, medicineCharges, labCharges, otherCharges, discount, totalAmount, paymentStatus, paymentMethod, date };
    }
}
