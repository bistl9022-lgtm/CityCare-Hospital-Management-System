package dao;

import model.MedicalRecord;

import java.sql.ResultSet;
import java.sql.SQLException;

/** Data access for the medical_records table. */
public class MedicalRecordDAO extends BaseDAO<MedicalRecord> {

    private static final String[] COLS = {
        "record_id", "patient_id", "doctor_id", "diagnosis", "symptoms", "treatment", "prescription", "test_results", "notes", "record_date"
    };

    public MedicalRecordDAO() { super("medical_records", COLS); }

    @Override
    protected MedicalRecord map(ResultSet rs) throws SQLException {
        return new MedicalRecord(
            rs.getString("record_id"),
            rs.getString("patient_id"),
            rs.getString("doctor_id"),
            rs.getString("diagnosis"),
            rs.getString("symptoms"),
            rs.getString("treatment"),
            rs.getString("prescription"),
            rs.getString("test_results"),
            rs.getString("notes"),
            rs.getString("record_date"));
    }

    @Override
    protected Object[] params(MedicalRecord t) {
        return new Object[]{
            t.getRecordId(), t.getPatientId(), t.getDoctorId(), t.getDiagnosis(), t.getSymptoms(), t.getTreatment(), t.getPrescription(), t.getTestResults(), t.getNotes(), t.getDate()
        };
    }
}
