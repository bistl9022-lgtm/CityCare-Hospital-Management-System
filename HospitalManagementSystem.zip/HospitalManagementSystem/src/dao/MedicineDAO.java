package dao;

import model.Medicine;

import java.sql.ResultSet;
import java.sql.SQLException;

/** Data access for the medicines table. */
public class MedicineDAO extends BaseDAO<Medicine> {

    private static final String[] COLS = {
        "medicine_id", "name", "category", "quantity", "price", "expiry_date", "supplier"
    };

    public MedicineDAO() { super("medicines", COLS); }

    @Override
    protected Medicine map(ResultSet rs) throws SQLException {
        return new Medicine(
            rs.getString("medicine_id"),
            rs.getString("name"),
            rs.getString("category"),
            rs.getInt("quantity"),
            rs.getDouble("price"),
            rs.getString("expiry_date"),
            rs.getString("supplier"));
    }

    @Override
    protected Object[] params(Medicine t) {
        return new Object[]{
            t.getMedicineId(), t.getName(), t.getCategory(), t.getQuantity(), t.getPrice(), t.getExpiryDate(), t.getSupplier()
        };
    }

    public static final int LOW_STOCK_LEVEL = 25;

    public java.util.List<model.Medicine> lowStock() throws java.sql.SQLException {
        return where(" WHERE quantity <= ?", LOW_STOCK_LEVEL);
    }

    public java.util.List<model.Medicine> expired(String today) throws java.sql.SQLException {
        return where(" WHERE expiry_date <> '' AND expiry_date < ?", today);
    }

    public int lowStockCount() {
        return (int) database.DBConnection.scalar(
                "SELECT COUNT(*) FROM medicines WHERE quantity <= " + LOW_STOCK_LEVEL);
    }
}
