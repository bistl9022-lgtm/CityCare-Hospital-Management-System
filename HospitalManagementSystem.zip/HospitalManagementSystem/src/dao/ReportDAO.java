package dao;

import database.DBConnection;
import model.TableData;

import java.sql.*;

/** Runs the read-only queries used by the Reports screen and global search. */
public class ReportDAO {

    /** Executes any SELECT and packs the result into a TableData. */
    public static TableData run(String sql, Object... args) throws SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = DBConnection.get().prepareStatement(sql);
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            rs = ps.executeQuery();

            ResultSetMetaData md = rs.getMetaData();
            int n = md.getColumnCount();
            String[] cols = new String[n];
            for (int i = 0; i < n; i++) cols[i] = md.getColumnLabel(i + 1);

            TableData data = new TableData(cols);
            while (rs.next()) {
                Object[] row = new Object[n];
                for (int i = 0; i < n; i++) row[i] = rs.getObject(i + 1);
                data.rows.add(row);
            }
            return data;
        } finally {
            BaseDAO.close(rs, ps);
        }
    }

    /** First column of a query as a combo-box option list. */
    public static String[] column(String sql, String... firstEntries) {
        java.util.List<String> list = new java.util.ArrayList<String>(
                java.util.Arrays.asList(firstEntries));
        try {
            model.TableData d = run(sql);
            for (Object[] row : d.rows) list.add(String.valueOf(row[0]));
        } catch (Exception ignored) { }
        if (list.isEmpty()) list.add("");
        return list.toArray(new String[0]);
    }
}
