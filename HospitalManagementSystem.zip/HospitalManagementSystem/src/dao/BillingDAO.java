package dao;

import model.Bill;

import java.sql.ResultSet;
import java.sql.SQLException;

/** Data access for the bills table. */
public class BillingDAO extends BaseDAO<Bill> {

    private static final String[] COLS = {
        "bill_id", "patient_id", "patient_name", "consultation_fee", "room_charges", "medicine_charges", "lab_charges", "other_charges", "discount", "total_amount", "payment_status", "payment_method", "bill_date"
    };

    public BillingDAO() { super("bills", COLS); }

    @Override
    protected Bill map(ResultSet rs) throws SQLException {
        return new Bill(
            rs.getString("bill_id"),
            rs.getString("patient_id"),
            rs.getString("patient_name"),
            rs.getDouble("consultation_fee"),
            rs.getDouble("room_charges"),
            rs.getDouble("medicine_charges"),
            rs.getDouble("lab_charges"),
            rs.getDouble("other_charges"),
            rs.getDouble("discount"),
            rs.getDouble("total_amount"),
            rs.getString("payment_status"),
            rs.getString("payment_method"),
            rs.getString("bill_date"));
    }

    @Override
    protected Object[] params(Bill t) {
        return new Object[]{
            t.getBillId(), t.getPatientId(), t.getPatientName(), t.getConsultationFee(), t.getRoomCharges(), t.getMedicineCharges(), t.getLabCharges(), t.getOtherCharges(), t.getDiscount(), t.getTotalAmount(), t.getPaymentStatus(), t.getPaymentMethod(), t.getDate()
        };
    }

    public java.util.List<model.Bill> byStatus(String status) throws java.sql.SQLException {
        return where(" WHERE payment_status = ?", status);
    }

    public int pendingCount() {
        return (int) database.DBConnection.scalar(
                "SELECT COUNT(*) FROM bills WHERE payment_status <> 'Paid'");
    }

    public double pendingAmount() {
        return database.DBConnection.scalar(
                "SELECT IFNULL(SUM(total_amount),0) FROM bills WHERE payment_status <> 'Paid'");
    }
}
