package dao;

import model.Patient;

import java.sql.ResultSet;
import java.sql.SQLException;

/** Data access for the patients table. */
public class PatientDAO extends BaseDAO<Patient> {

    private static final String[] COLS = {
        "patient_id", "full_name", "age", "gender", "dob", "phone", "email", "address", "blood_group", "emergency_contact", "disease", "admission_date", "room_no", "doctor", "priority"
    };

    public PatientDAO() { super("patients", COLS); }

    @Override
    protected Patient map(ResultSet rs) throws SQLException {
        return new Patient(
            rs.getString("patient_id"),
            rs.getString("full_name"),
            rs.getInt("age"),
            rs.getString("gender"),
            rs.getString("dob"),
            rs.getString("phone"),
            rs.getString("email"),
            rs.getString("address"),
            rs.getString("blood_group"),
            rs.getString("emergency_contact"),
            rs.getString("disease"),
            rs.getString("admission_date"),
            rs.getString("room_no"),
            rs.getString("doctor"),
            rs.getString("priority"));
    }

    @Override
    protected Object[] params(Patient t) {
        return new Object[]{
            t.getPatientId(), t.getFullName(), t.getAge(), t.getGender(), t.getDob(), t.getPhone(), t.getEmail(), t.getAddress(), t.getBloodGroup(), t.getEmergencyContact(), t.getDisease(), t.getAdmissionDate(), t.getRoomNo(), t.getDoctor(), t.getPriority()
        };
    }

    /** Patients that the rule-based classifier marked as needing urgent care. */
    public java.util.List<model.Patient> byPriority(String priority) throws java.sql.SQLException {
        return where(" WHERE priority = ?", priority);
    }

    /** Beds currently occupied = patients that have a room number assigned. */
    public int occupiedBeds() {
        return (int) database.DBConnection.scalar(
                "SELECT COUNT(*) FROM patients WHERE room_no IS NOT NULL AND room_no <> ''");
    }
}
