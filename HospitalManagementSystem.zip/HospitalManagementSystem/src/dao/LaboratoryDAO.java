package dao;

import model.LaboratoryTest;

import java.sql.ResultSet;
import java.sql.SQLException;

/** Data access for the laboratory_tests table. */
public class LaboratoryDAO extends BaseDAO<LaboratoryTest> {

    private static final String[] COLS = {
        "test_id", "patient_id", "patient_name", "test_name", "doctor", "test_date", "result", "status", "cost"
    };

    public LaboratoryDAO() { super("laboratory_tests", COLS); }

    @Override
    protected LaboratoryTest map(ResultSet rs) throws SQLException {
        return new LaboratoryTest(
            rs.getString("test_id"),
            rs.getString("patient_id"),
            rs.getString("patient_name"),
            rs.getString("test_name"),
            rs.getString("doctor"),
            rs.getString("test_date"),
            rs.getString("result"),
            rs.getString("status"),
            rs.getDouble("cost"));
    }

    @Override
    protected Object[] params(LaboratoryTest t) {
        return new Object[]{
            t.getTestId(), t.getPatientId(), t.getPatientName(), t.getTestName(), t.getDoctor(), t.getTestDate(), t.getResult(), t.getStatus(), t.getCost()
        };
    }

    public java.util.List<model.LaboratoryTest> byStatus(String status) throws java.sql.SQLException {
        return where(" WHERE status = ?", status);
    }
}
