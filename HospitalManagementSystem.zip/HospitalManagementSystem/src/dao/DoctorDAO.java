package dao;

import model.Doctor;

import java.sql.ResultSet;
import java.sql.SQLException;

/** Data access for the doctors table. */
public class DoctorDAO extends BaseDAO<Doctor> {

    private static final String[] COLS = {
        "doctor_id", "name", "specialization", "gender", "phone", "email", "experience", "qualification", "availability", "room_no"
    };

    public DoctorDAO() { super("doctors", COLS); }

    @Override
    protected Doctor map(ResultSet rs) throws SQLException {
        return new Doctor(
            rs.getString("doctor_id"),
            rs.getString("name"),
            rs.getString("specialization"),
            rs.getString("gender"),
            rs.getString("phone"),
            rs.getString("email"),
            rs.getInt("experience"),
            rs.getString("qualification"),
            rs.getString("availability"),
            rs.getString("room_no"));
    }

    @Override
    protected Object[] params(Doctor t) {
        return new Object[]{
            t.getDoctorId(), t.getName(), t.getSpecialization(), t.getGender(), t.getPhone(), t.getEmail(), t.getExperience(), t.getQualification(), t.getAvailability(), t.getRoomNo()
        };
    }

    public java.util.List<model.Doctor> available() throws java.sql.SQLException {
        return where(" WHERE availability = ?", "Available");
    }
}
