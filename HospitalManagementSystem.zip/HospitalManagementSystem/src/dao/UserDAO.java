package dao;

import database.DBConnection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/** Login lookups. Kept separate because users are not shown in any JTable. */
public class UserDAO {

    /**
     * @return the display name of the user when the credentials match, else null.
     */
    public String authenticate(String username, String password) throws SQLException {
        String sql = "SELECT full_name, role FROM users WHERE username = ? AND password = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = DBConnection.get().prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            rs = ps.executeQuery();
            if (rs.next()) return rs.getString("full_name") + " (" + rs.getString("role") + ")";
            return null;
        } finally {
            BaseDAO.close(rs, ps);
        }
    }
}
