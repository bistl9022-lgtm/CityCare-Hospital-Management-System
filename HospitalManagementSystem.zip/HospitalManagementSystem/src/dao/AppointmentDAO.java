package dao;

import model.Appointment;

import java.sql.ResultSet;
import java.sql.SQLException;

/** Data access for the appointments table. */
public class AppointmentDAO extends BaseDAO<Appointment> {

    private static final String[] COLS = {
        "appointment_id", "patient_id", "doctor_id", "appt_date", "appt_time", "department", "reason", "status"
    };

    public AppointmentDAO() { super("appointments", COLS); }

    @Override
    protected Appointment map(ResultSet rs) throws SQLException {
        return new Appointment(
            rs.getString("appointment_id"),
            rs.getString("patient_id"),
            rs.getString("doctor_id"),
            rs.getString("appt_date"),
            rs.getString("appt_time"),
            rs.getString("department"),
            rs.getString("reason"),
            rs.getString("status"));
    }

    @Override
    protected Object[] params(Appointment t) {
        return new Object[]{
            t.getAppointmentId(), t.getPatientId(), t.getDoctorId(), t.getDate(), t.getTime(), t.getDepartment(), t.getReason(), t.getStatus()
        };
    }

    public java.util.List<model.Appointment> onDate(String date) throws java.sql.SQLException {
        return where(" WHERE appt_date = ?", date);
    }

    public int countOn(String date) {
        return (int) database.DBConnection.scalar(
                "SELECT COUNT(*) FROM appointments WHERE appt_date = ?", date);
    }

    public int countEmergency() {
        return (int) database.DBConnection.scalar(
                "SELECT COUNT(*) FROM appointments WHERE status = 'Emergency'");
    }
}
