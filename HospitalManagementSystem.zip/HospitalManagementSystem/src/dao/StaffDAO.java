package dao;

import model.Staff;

import java.sql.ResultSet;
import java.sql.SQLException;

/** Data access for the staff table. */
public class StaffDAO extends BaseDAO<Staff> {

    private static final String[] COLS = {
        "staff_id", "name", "role", "department", "phone", "email", "salary", "joining_date", "shift"
    };

    public StaffDAO() { super("staff", COLS); }

    @Override
    protected Staff map(ResultSet rs) throws SQLException {
        return new Staff(
            rs.getString("staff_id"),
            rs.getString("name"),
            rs.getString("role"),
            rs.getString("department"),
            rs.getString("phone"),
            rs.getString("email"),
            rs.getDouble("salary"),
            rs.getString("joining_date"),
            rs.getString("shift"));
    }

    @Override
    protected Object[] params(Staff t) {
        return new Object[]{
            t.getStaffId(), t.getName(), t.getRole(), t.getDepartment(), t.getPhone(), t.getEmail(), t.getSalary(), t.getJoiningDate(), t.getShift()
        };
    }
}
