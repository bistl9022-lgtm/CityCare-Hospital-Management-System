-- ============================================================
--  Hospital Management System - MySQL schema + seed data
--  Run:  mysql -u root -p < hospital.sql
-- ============================================================
DROP DATABASE IF EXISTS hospital_db;
CREATE DATABASE hospital_db CHARACTER SET utf8mb4;
USE hospital_db;

CREATE TABLE users (
    username  VARCHAR(40) PRIMARY KEY,
    password  VARCHAR(80)  NOT NULL,
    full_name VARCHAR(80)  NOT NULL,
    role      VARCHAR(30)  NOT NULL
);

CREATE TABLE patients (
    patient_id        VARCHAR(20) PRIMARY KEY,
    full_name         VARCHAR(80)  NOT NULL,
    age               INT,
    gender            VARCHAR(15),
    dob               VARCHAR(15),
    phone             VARCHAR(20),
    email             VARCHAR(80),
    address           VARCHAR(150),
    blood_group       VARCHAR(10),
    emergency_contact VARCHAR(20),
    disease           VARCHAR(150),
    admission_date    VARCHAR(15),
    room_no           VARCHAR(15),
    doctor            VARCHAR(80),
    priority          VARCHAR(20) DEFAULT 'Medium Priority'
);

CREATE TABLE doctors (
    doctor_id      VARCHAR(20) PRIMARY KEY,
    name           VARCHAR(80) NOT NULL,
    specialization VARCHAR(60),
    gender         VARCHAR(15),
    phone          VARCHAR(20),
    email          VARCHAR(80),
    experience     INT,
    qualification  VARCHAR(80),
    availability   VARCHAR(30),
    room_no        VARCHAR(15)
);

CREATE TABLE appointments (
    appointment_id VARCHAR(20) PRIMARY KEY,
    patient_id     VARCHAR(20),
    doctor_id      VARCHAR(20),
    appt_date      VARCHAR(15),
    appt_time      VARCHAR(10),
    department     VARCHAR(50),
    reason         VARCHAR(150),
    status         VARCHAR(20)
);

CREATE TABLE medical_records (
    record_id    VARCHAR(20) PRIMARY KEY,
    patient_id   VARCHAR(20),
    doctor_id    VARCHAR(20),
    diagnosis    VARCHAR(150),
    symptoms     VARCHAR(200),
    treatment    VARCHAR(200),
    prescription VARCHAR(200),
    test_results VARCHAR(200),
    notes        VARCHAR(200),
    record_date  VARCHAR(15)
);

CREATE TABLE bills (
    bill_id          VARCHAR(20) PRIMARY KEY,
    patient_id       VARCHAR(20),
    patient_name     VARCHAR(80),
    consultation_fee DECIMAL(10,2) DEFAULT 0,
    room_charges     DECIMAL(10,2) DEFAULT 0,
    medicine_charges DECIMAL(10,2) DEFAULT 0,
    lab_charges      DECIMAL(10,2) DEFAULT 0,
    other_charges    DECIMAL(10,2) DEFAULT 0,
    discount         DECIMAL(10,2) DEFAULT 0,
    total_amount     DECIMAL(10,2) DEFAULT 0,
    payment_status   VARCHAR(20),
    payment_method   VARCHAR(20),
    bill_date        VARCHAR(15)
);

CREATE TABLE medicines (
    medicine_id VARCHAR(20) PRIMARY KEY,
    name        VARCHAR(80) NOT NULL,
    category    VARCHAR(50),
    quantity    INT DEFAULT 0,
    price       DECIMAL(10,2) DEFAULT 0,
    expiry_date VARCHAR(15),
    supplier    VARCHAR(80)
);

CREATE TABLE laboratory_tests (
    test_id      VARCHAR(20) PRIMARY KEY,
    patient_id   VARCHAR(20),
    patient_name VARCHAR(80),
    test_name    VARCHAR(80),
    doctor       VARCHAR(80),
    test_date    VARCHAR(15),
    result       VARCHAR(200),
    status       VARCHAR(20),
    cost         DECIMAL(10,2) DEFAULT 0
);

CREATE TABLE staff (
    staff_id     VARCHAR(20) PRIMARY KEY,
    name         VARCHAR(80) NOT NULL,
    role         VARCHAR(40),
    department   VARCHAR(50),
    phone        VARCHAR(20),
    email        VARCHAR(80),
    salary       DECIMAL(10,2) DEFAULT 0,
    joining_date VARCHAR(15),
    shift        VARCHAR(20)
);

-- ------------------------- seed data -------------------------
INSERT INTO users VALUES
 ('admin','admin123','Dr. A. Mohanty','Administrator'),
 ('reception','recep123','Sunita Das','Receptionist');

INSERT INTO doctors VALUES
 ('D001','Dr. Ramesh Patnaik','Cardiology','Male','9876543210','ramesh@hospital.com',14,'MD, DM Cardiology','Available','C-101'),
 ('D002','Dr. Anita Sahoo','Pediatrics','Female','9876500011','anita@hospital.com',9,'MBBS, MD','Available','P-204'),
 ('D003','Dr. Vikram Rao','Orthopedics','Male','9876500022','vikram@hospital.com',11,'MS Ortho','On Leave','O-110'),
 ('D004','Dr. Meera Nair','Neurology','Female','9876500033','meera@hospital.com',16,'MD, DM Neuro','Available','N-301');

INSERT INTO patients VALUES
 ('P001','Rahul Mishra',34,'Male','1992-04-11','9090901010','rahul@mail.com','Saheed Nagar, Bhubaneswar','B+','9090901011','Chest pain and breathlessness','2026-09-18','R-201','Dr. Ramesh Patnaik','Emergency'),
 ('P002','Priya Sahu',7,'Female','2019-02-02','9090902020','priya@mail.com','Patia, Bhubaneswar','O+','9090902021','High fever with cough','2026-09-19','R-105','Dr. Anita Sahoo','High Priority'),
 ('P003','Sanjay Behera',58,'Male','1968-07-23','9090903030','sanjay@mail.com','Cuttack Road','A+','9090903031','Fracture in left leg','2026-09-19','R-310','Dr. Vikram Rao','Medium Priority'),
 ('P004','Kavita Jena',29,'Female','1997-01-15','9090904040','kavita@mail.com','Jaydev Vihar','AB+','9090904041','Routine health checkup','2026-09-20','','Dr. Meera Nair','Low Priority');

INSERT INTO appointments VALUES
 ('A001','P001','D001','2026-09-20','10:00','Cardiology','Severe chest pain','Emergency'),
 ('A002','P002','D002','2026-09-20','11:30','Pediatrics','Fever follow-up','Scheduled'),
 ('A003','P003','D003','2026-09-21','09:15','Orthopedics','Plaster check','Scheduled'),
 ('A004','P004','D004','2026-09-19','16:00','Neurology','Headache consultation','Completed');

INSERT INTO medical_records VALUES
 ('MR001','P001','D001','Acute angina','Chest pain, sweating','Oxygen, nitrates','Sorbitrate 5mg','ECG abnormal','Admitted to ICU','2026-09-18'),
 ('MR002','P002','D002','Viral fever','Fever 103F, cough','IV fluids, antipyretics','Paracetamol syrup','CBC normal','Monitor for 2 days','2026-09-19');

INSERT INTO bills VALUES
 ('B001','P001','Rahul Mishra',800,4500,2200,1500,300,10,8370,'Pending','Cash','2026-09-19'),
 ('B002','P004','Kavita Jena',500,0,250,900,0,0,1650,'Paid','UPI','2026-09-19');

INSERT INTO medicines VALUES
 ('M001','Paracetamol 500mg','Tablet',420,2.50,'2027-05-30','MediCorp Ltd'),
 ('M002','Amoxicillin 250mg','Capsule',18,6.75,'2026-11-10','HealWell Pharma'),
 ('M003','Cough Syrup 100ml','Syrup',65,88.00,'2026-08-01','HealWell Pharma'),
 ('M004','Insulin Injection','Injection',9,320.00,'2027-01-20','BioLife'),
 ('M005','ORS Sachet','Powder',300,18.00,'2028-03-15','MediCorp Ltd');

INSERT INTO laboratory_tests VALUES
 ('L001','P001','Rahul Mishra','ECG','Dr. Ramesh Patnaik','2026-09-18','ST elevation observed','Completed',1200),
 ('L002','P002','Priya Sahu','Complete Blood Count','Dr. Anita Sahoo','2026-09-19','','Processing',450),
 ('L003','P003','Sanjay Behera','X-Ray Left Leg','Dr. Vikram Rao','2026-09-19','','Pending',900);

INSERT INTO staff VALUES
 ('S001','Sunita Das','Receptionist','Front Desk','9876511111','sunita@hospital.com',22000,'2023-06-01','Morning'),
 ('S002','Manoj Kar','Nurse','ICU','9876522222','manoj@hospital.com',28000,'2022-02-15','Night'),
 ('S003','Reena Pradhan','Pharmacist','Pharmacy','9876533333','reena@hospital.com',31000,'2021-09-10','Morning'),
 ('S004','Ajay Sethi','Technician','Laboratory','9876544444','ajay@hospital.com',26000,'2024-01-05','Evening');
